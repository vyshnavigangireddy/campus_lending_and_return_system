@echo off
title Stop Campus Item Lending Server
echo ======================================================================
echo    Stopping Campus Item Lending Server on Port 8080...
echo ======================================================================

for /f "tokens=5" %%a in ('netstat -aon ^| find ":8080" ^| find "LISTENING"') do (
    echo [INFO] Found process PID: %%a listening on port 8080. Terminating...
    taskkill /F /PID %%a >nul 2>&1
)

echo [SUCCESS] Server stopped cleanly.
ping 127.0.0.1 -n 2 >nul
exit /b 0
