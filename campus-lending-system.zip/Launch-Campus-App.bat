@echo off
title Campus Item Lending & Return System App
cd /d "%~dp0"

echo ======================================================================
echo    Launching Campus Item Lending System (App Window Mode)
echo ======================================================================

REM 1. Check if server is already running on port 8080
netstat -ano | findstr :8080 | findstr LISTENING >nul
if %errorlevel% equ 0 (
    echo [INFO] Server is already active on port 8080.
    goto launch_app
)

REM 2. Start server in persistent background mode (javaw runs with no command window)
echo [INFO] Starting Campus Lending Server in persistent background mode...
if exist "target\campus-lending-system-1.0.0.jar" (
    where javaw >nul 2>nul
    if %errorlevel% equ 0 (
        start "" javaw -jar target\campus-lending-system-1.0.0.jar
    ) else (
        start "Campus Lending Server" /b java -jar target\campus-lending-system-1.0.0.jar
    )
) else (
    start "Campus Lending Server" /b cmd /c "mvnw.cmd spring-boot:run"
)

REM 3. Wait until port 8080 responds (up to 20 attempts)
echo [INFO] Waiting for application to initialize...
set /a attempts=0
:wait_loop
ping 127.0.0.1 -n 2 >nul
netstat -ano | findstr :8080 | findstr LISTENING >nul
if %errorlevel% equ 0 goto launch_app
set /a attempts+=1
if %attempts% lss 20 goto wait_loop

:launch_app
echo [INFO] Server is online! Launching standalone application window...

REM Check for Edge or Chrome to launch in dedicated app window mode
if exist "%ProgramFiles(x86)%\Microsoft\Edge\Application\msedge.exe" (
    start "" "%ProgramFiles(x86)%\Microsoft\Edge\Application\msedge.exe" --app=http://localhost:8080/catalog --window-size=1400,900
    exit /b 0
)
if exist "%ProgramFiles%\Microsoft\Edge\Application\msedge.exe" (
    start "" "%ProgramFiles%\Microsoft\Edge\Application\msedge.exe" --app=http://localhost:8080/catalog --window-size=1400,900
    exit /b 0
)
if exist "%ProgramFiles%\Google\Chrome\Application\chrome.exe" (
    start "" "%ProgramFiles%\Google\Chrome\Application\chrome.exe" --app=http://localhost:8080/catalog --window-size=1400,900
    exit /b 0
)
if exist "%ProgramFiles(x86)%\Google\Chrome\Application\chrome.exe" (
    start "" "%ProgramFiles(x86)%\Google\Chrome\Application\chrome.exe" --app=http://localhost:8080/catalog --window-size=1400,900
    exit /b 0
)
if exist "%LocalAppData%\Google\Chrome\Application\chrome.exe" (
    start "" "%LocalAppData%\Google\Chrome\Application\chrome.exe" --app=http://localhost:8080/catalog --window-size=1400,900
    exit /b 0
)
if exist "%LocalAppData%\Microsoft\Edge\Application\msedge.exe" (
    start "" "%LocalAppData%\Microsoft\Edge\Application\msedge.exe" --app=http://localhost:8080/catalog --window-size=1400,900
    exit /b 0
)

REM Fallback to default browser
start http://localhost:8080/catalog
exit /b 0
