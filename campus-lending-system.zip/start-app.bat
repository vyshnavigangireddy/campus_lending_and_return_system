@echo off
title Campus Item Lending ^& Return System
cd /d "%~dp0"

echo ======================================================================
echo    Starting Campus Item Lending ^& Return System (Permanent Mode)
echo ======================================================================

REM Check if application is already running on port 8080
netstat -ano | findstr :8080 | findstr LISTENING >nul
if %errorlevel% equ 0 (
    echo [INFO] Application is already running on port 8080!
    echo [INFO] Opening browser...
    start http://localhost:8080/catalog
    exit /b 0
)

REM Check if compiled JAR exists
if exist "target\campus-lending-system-1.0.0.jar" (
    echo [INFO] Launching standalone JAR package in background...
    where javaw >nul 2>nul
    if %errorlevel% equ 0 (
        start "" javaw -jar target\campus-lending-system-1.0.0.jar
    ) else (
        start "Campus Lending Server" /b java -jar target\campus-lending-system-1.0.0.jar
    )
) else (
    echo [INFO] Launching via Maven...
    start "Campus Lending Server" /b cmd /c "mvnw.cmd spring-boot:run"
)

echo [INFO] Waiting 5 seconds for server initialization...
ping 127.0.0.1 -n 6 >nul

echo [INFO] Launching web browser...
start http://localhost:8080/catalog

echo ======================================================================
echo    Campus Lending Portal is active at: http://localhost:8080/catalog
echo    To stop the server anytime, run: stop-app.bat
echo ======================================================================
exit /b 0
