package com.campus.lending.model;

public enum RequestStatus {
    PENDING("Pending Approval"),
    APPROVED("Awaiting Pickup"),
    LOANED("Item Issued / Given"),
    REJECTED("Declined"),
    RETURNED("Returned");

    private final String displayName;

    RequestStatus(String displayName) {
        this.displayName = displayName;
    }

    public String getDisplayName() {
        return displayName;
    }
}
