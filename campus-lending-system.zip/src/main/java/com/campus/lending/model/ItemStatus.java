package com.campus.lending.model;

public enum ItemStatus {
    AVAILABLE,
    BORROWED
}
