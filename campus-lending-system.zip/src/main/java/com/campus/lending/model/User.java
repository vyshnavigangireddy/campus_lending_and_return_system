package com.campus.lending.model;

import jakarta.persistence.*;
import jakarta.validation.constraints.Email;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Size;
import java.time.LocalDateTime;

@Entity
@Table(name = "users")
public class User {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @NotBlank(message = "Name cannot be empty")
    @Size(max = 100)
    @Column(nullable = false, length = 100)
    private String name;

    @NotBlank(message = "Email is required")
    @Email(message = "Please provide a valid email address")
    @Size(max = 150)
    @Column(nullable = false, unique = true, length = 150)
    private String email;

    @Enumerated(EnumType.STRING)
    @Column(nullable = false, length = 30)
    private Role role = Role.STUDENT;

    @Column(name = "created_at", nullable = false, updatable = false)
    private LocalDateTime createdAt = LocalDateTime.now();

    public User() {
    }

    public User(String name, String email, Role role) {
        this.name = name;
        this.email = email;
        this.role = role != null ? role : Role.STUDENT;
        this.createdAt = LocalDateTime.now();
    }

    @PrePersist
    protected void onCreate() {
        if (createdAt == null) {
            createdAt = LocalDateTime.now();
        }
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public Role getRole() {
        return role;
    }

    public void setRole(Role role) {
        this.role = role;
    }

    public LocalDateTime getCreatedAt() {
        return createdAt;
    }

    public void setCreatedAt(LocalDateTime createdAt) {
        this.createdAt = createdAt;
    }

    public boolean isStudent() {
        return role == Role.STUDENT;
    }

    public boolean isLender() {
        return role == Role.LENDER || role == Role.ADMIN;
    }

    public boolean isLabIncharge() {
        return role == Role.LENDER || role == Role.ADMIN;
    }

    public boolean isApprover() {
        return role == Role.APPROVER || role == Role.ADMIN;
    }

    public boolean isAdmin() {
        return role == Role.ADMIN;
    }

    /**
     * Extracts uppercase 1-2 letter initials from the user's name or email.
     */
    public String getInitials() {
        if (name != null && !name.trim().isEmpty()) {
            String[] parts = name.trim().split("\\s+");
            if (parts.length >= 2) {
                return ("" + parts[0].charAt(0) + parts[1].charAt(0)).toUpperCase();
            } else if (parts[0].length() >= 2) {
                return parts[0].substring(0, 2).toUpperCase();
            } else {
                return parts[0].substring(0, 1).toUpperCase();
            }
        }
        if (email != null && !email.trim().isEmpty()) {
            String prefix = email.split("@")[0];
            return prefix.length() >= 2 ? prefix.substring(0, 2).toUpperCase() : prefix.toUpperCase();
        }
        return "U";
    }

    /**
     * Deterministic stylish gradient index for avatar display.
     */
    public String getAvatarGradient() {
        int hash = Math.abs((email != null ? email : "user").hashCode());
        String[] gradients = {
            "linear-gradient(135deg, #6366F1, #8B5CF6)", // Indigo to Purple
            "linear-gradient(135deg, #3B82F6, #06B6D4)", // Blue to Cyan
            "linear-gradient(135deg, #10B981, #059669)", // Emerald
            "linear-gradient(135deg, #F59E0B, #D97706)", // Amber
            "linear-gradient(135deg, #EC4899, #8B5CF6)", // Pink to Violet
            "linear-gradient(135deg, #4F46E5, #3B82F6)"  // Indigo to Blue
        };
        return gradients[hash % gradients.length];
    }
}
