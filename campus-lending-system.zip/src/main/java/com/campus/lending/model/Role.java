package com.campus.lending.model;

public enum Role {
    STUDENT("Student Borrower"),
    LENDER("Lab Incharge"),
    APPROVER("Campus Facility Approver"),
    ADMIN("System Administrator");

    private final String displayName;

    Role(String displayName) {
        this.displayName = displayName;
    }

    public String getDisplayName() {
        return displayName;
    }
}
