package com.campus.lending;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.scheduling.annotation.EnableScheduling;

@SpringBootApplication
@EnableScheduling
public class CampusLendingApplication {

    public static void main(String[] args) {
        SpringApplication.run(CampusLendingApplication.class, args);
    }
}
