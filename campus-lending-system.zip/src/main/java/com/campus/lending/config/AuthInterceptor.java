package com.campus.lending.config;

import com.campus.lending.model.User;
import com.campus.lending.service.UserService;
import jakarta.servlet.http.Cookie;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;
import org.springframework.stereotype.Component;
import org.springframework.web.servlet.HandlerInterceptor;

import java.util.Optional;

@Component
public class AuthInterceptor implements HandlerInterceptor {

    public static final String REMEMBER_COOKIE_NAME = "campus_remember_email";

    private final UserService userService;

    public AuthInterceptor(UserService userService) {
        this.userService = userService;
    }

    @Override
    public boolean preHandle(HttpServletRequest request, HttpServletResponse response, Object handler) {
        // Support smooth browser Back/Forward (bfcache) navigation without freezing or ERR_CACHE_MISS
        response.setHeader("Cache-Control", "private, no-cache");

        HttpSession session = request.getSession(true);

        // If session already has current user, keep going
        if (session.getAttribute("currentUser") != null) {
            return true;
        }

        // Check if a permanent login cookie exists
        Cookie[] cookies = request.getCookies();
        if (cookies != null) {
            for (Cookie cookie : cookies) {
                if (REMEMBER_COOKIE_NAME.equals(cookie.getName())) {
                    String email = cookie.getValue();
                    if (email != null && !email.trim().isEmpty()) {
                        Optional<User> userOpt = userService.findByEmail(email.trim());
                        if (userOpt.isPresent()) {
                            // Restore session permanently
                            session.setAttribute("currentUser", userOpt.get());
                        }
                    }
                    break;
                }
            }
        }

        return true;
    }
}
