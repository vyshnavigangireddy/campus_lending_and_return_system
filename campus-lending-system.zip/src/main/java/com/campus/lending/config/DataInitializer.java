package com.campus.lending.config;

import com.campus.lending.model.*;
import com.campus.lending.repository.BorrowRequestRepository;
import com.campus.lending.repository.ItemRepository;
import com.campus.lending.repository.UserRepository;
import org.springframework.boot.CommandLineRunner;
import org.springframework.stereotype.Component;

import java.time.LocalDate;

@Component
public class DataInitializer implements CommandLineRunner {

    private final UserRepository userRepository;
    private final ItemRepository itemRepository;
    private final BorrowRequestRepository borrowRequestRepository;

    public DataInitializer(UserRepository userRepository,
                           ItemRepository itemRepository,
                           BorrowRequestRepository borrowRequestRepository) {
        this.userRepository = userRepository;
        this.itemRepository = itemRepository;
        this.borrowRequestRepository = borrowRequestRepository;
    }

    @Override
    public void run(String... args) {
        if (userRepository.count() > 0) {
            return; // Data already present
        }

        // 1. Seed Users (Students, Lab Incharges, Approvers, Admin)
        User lenderAlice = userRepository.save(new User(
            "Prof. Alice Vance", "alice.labincharge@college.edu", Role.LENDER
        ));

        User approverMiller = userRepository.save(new User(
            "Dr. Robert Miller", "miller.approver@college.edu", Role.APPROVER
        ));

        User studentBob = userRepository.save(new User(
            "Bob Sharma", "bob.student@college.edu", Role.STUDENT
        ));

        User studentElena = userRepository.save(new User(
            "Elena Rostova", "elena.student@college.edu", Role.STUDENT
        ));

        User adminOps = userRepository.save(new User(
            "Campus Facility Admin", "admin.facility@college.edu", Role.ADMIN
        ));

        // 2. Seed Items across categories
        Item item1 = itemRepository.save(new Item(
            lenderAlice,
            "Digital Storage Oscilloscope 100MHz (Rigol DS1054Z)",
            "Electronics",
            "4-channel 100MHz digital oscilloscope with UltraVision technology, 24Mpts memory depth, and 4 passive probes. Perfect for hardware circuit debugging.",
            ItemStatus.AVAILABLE,
            "https://images.unsplash.com/photo-1581092160607-ee22621dd758?auto=format&fit=crop&w=600&q=80"
        ));

        Item item2 = itemRepository.save(new Item(
            lenderAlice,
            "Texas Instruments TI-84 Plus CE Graphing Calculator",
            "Electronics",
            "High-resolution backlit color screen graphing calculator, preloaded with math and science apps. Includes charging USB cable.",
            ItemStatus.BORROWED,
            "https://images.unsplash.com/photo-1594980596870-8aa52a78d8cd?auto=format&fit=crop&w=600&q=80"
        ));

        Item item3 = itemRepository.save(new Item(
            lenderAlice,
            "Raspberry Pi 5 (8GB RAM) Embedded Kit",
            "Electronics",
            "Broadcom BCM2712 quad-core Cortex-A76, active cooler, official power supply, and 64GB high-speed microSD preloaded with Bookworm OS.",
            ItemStatus.AVAILABLE,
            "https://images.unsplash.com/photo-1629654297299-c8506221ca97?auto=format&fit=crop&w=600&q=80"
        ));

        Item item4 = itemRepository.save(new Item(
            approverMiller,
            "Advanced Organic Chemistry Glassware Kit (24/40)",
            "Lab Kits",
            "Heavy-duty borosilicate glassware set including round bottom flasks, condenser, distillation adapter, and separatory funnel in padded protective case.",
            ItemStatus.AVAILABLE,
            "https://images.unsplash.com/photo-1582719508461-905c673771fd?auto=format&fit=crop&w=600&q=80"
        ));

        Item item5 = itemRepository.save(new Item(
            approverMiller,
            "Vernier LabQuest 2 Multi-Sensor Station",
            "Lab Kits",
            "Standalone laboratory data logger with color touchscreen. Includes optical dissolved oxygen probe and precision pH electrode.",
            ItemStatus.AVAILABLE,
            "https://images.unsplash.com/photo-1532187863486-abf9dbad1b69?auto=format&fit=crop&w=600&q=80"
        ));

        Item item6 = itemRepository.save(new Item(
            lenderAlice,
            "TurtleBot3 Burger Mobile Robot (ROS2)",
            "Robotics & IoT",
            "Compact educational mobile robot equipped with 360-degree LiDAR LDS-01, OpenCR controller, and Raspberry Pi 4. Ready for SLAM and autonomous navigation.",
            ItemStatus.AVAILABLE,
            "https://images.unsplash.com/photo-1485827404703-89b55fcc595e?auto=format&fit=crop&w=600&q=80"
        ));

        Item item7 = itemRepository.save(new Item(
            studentBob,
            "Introduction to Algorithms (CLRS 4th Edition)",
            "Books & Courseware",
            "Comprehensive textbook covering algorithm analysis, graph theory, dynamic programming, and data structures. In immaculate condition with no markings.",
            ItemStatus.AVAILABLE,
            "https://images.unsplash.com/photo-1544716278-ca5e3f4abd8c?auto=format&fit=crop&w=600&q=80"
        ));

        Item item8 = itemRepository.save(new Item(
            adminOps,
            "Sony Alpha a6400 4K Mirrorless Camera + 16-50mm",
            "Audio & Visual",
            "Compact mirrorless camera with real-time Eye AF, 4K video recording, clean HDMI out, and lightweight Manfrotto tripod. Ideal for seminar documentation.",
            ItemStatus.AVAILABLE,
            "https://images.unsplash.com/photo-1516035069371-29a1b244cc32?auto=format&fit=crop&w=600&q=80"
        ));

        Item item9 = itemRepository.save(new Item(
            adminOps,
            "Wilson NCAA Official Game Basketball & Dual Pump",
            "Sports Gear",
            "Composite leather official size 7 basketball with moisture-wicking channels. Comes with brass dual-action hand pump and pressure gauge.",
            ItemStatus.BORROWED,
            "https://images.unsplash.com/photo-1519861531473-9200262188bf?auto=format&fit=crop&w=600&q=80"
        ));

        Item item10 = itemRepository.save(new Item(
            lenderAlice,
            "DJI Mini 4 Pro 4K Drone Aerial Surveying Kit",
            "Robotics & IoT",
            "Ultralight foldable drone with 4K/60fps HDR true vertical shooting, omnidirectional obstacle sensing, and 20km FHD video transmission for campus mapping.",
            ItemStatus.AVAILABLE,
            "https://images.unsplash.com/photo-1527977966376-1c8408f9f108?auto=format&fit=crop&w=600&q=80"
        ));

        Item item11 = itemRepository.save(new Item(
            lenderAlice,
            "Creality Ender-3 V3 High-Speed 3D Printer (250mm/s)",
            "Electronics",
            "CoreXZ 3D printer with direct drive extruder, automatic bed leveling, and 220x220x250mm build volume. Includes 1kg spool of PLA filament.",
            ItemStatus.AVAILABLE,
            "https://images.unsplash.com/photo-1615996001375-c7ef13294436?auto=format&fit=crop&w=600&q=80"
        ));

        Item item12 = itemRepository.save(new Item(
            adminOps,
            "Bose QuietComfort 45 Active Noise-Cancelling Headphones",
            "Audio & Visual",
            "Over-ear acoustic noise cancelling headphones with TriPort acoustic architecture, 24-hour battery life, and high-fidelity sound for audio post-production.",
            ItemStatus.AVAILABLE,
            "https://images.unsplash.com/photo-1505740420928-5e560c06d30e?auto=format&fit=crop&w=600&q=80"
        ));

        Item item13 = itemRepository.save(new Item(
            approverMiller,
            "Olympus CX23 Binocular LED Biological Microscope",
            "Lab Kits",
            "Ergonomic student compound microscope with plan achromat objectives (4X, 10X, 40X, 100X oil) and energy-saving LED illumination system.",
            ItemStatus.AVAILABLE,
            "https://images.unsplash.com/photo-1516321318423-f06f85e504b3?auto=format&fit=crop&w=600&q=80"
        ));

        Item item14 = itemRepository.save(new Item(
            approverMiller,
            "Fluke 87V Industrial True-RMS Digital Multimeter",
            "Electronics",
            "Accurate voltage and frequency measurements on adjustable speed motor drives and other electrically noisy equipment. CAT IV 600V safety certified.",
            ItemStatus.AVAILABLE,
            "https://images.unsplash.com/photo-1581092335397-9583fe92d232?auto=format&fit=crop&w=600&q=80"
        ));

        // 3. Seed Borrow Requests (PENDING, APPROVED, RETURNED, REJECTED)
        // Request 1: Bob requests Oscilloscope (PENDING) -> shows Edit/Cancel for Bob, Approve/Decline for Alice
        BorrowRequest reqPending = new BorrowRequest(
            item1,
            studentBob,
            LocalDate.now(),
            LocalDate.now().plusDays(5),
            "ECE 410 Senior Design: Inverter noise ripple calibration and Fourier harmonics testing."
        );
        reqPending.setStatus(RequestStatus.PENDING);
        borrowRequestRepository.save(reqPending);

        // Request 2: Bob borrowed TI-84 calculator (LOANED / IN USE) -> DUE TOMORROW (triggers 1-day intimation reminder!)
        BorrowRequest reqApproved = new BorrowRequest(
            item2,
            studentBob,
            LocalDate.now().minusDays(5),
            LocalDate.now().plusDays(1), // Exactly 1 day before return date!
            "Multivariable Calculus Midterm Examination and matrix regression homework."
        );
        reqApproved.setStatus(RequestStatus.LOANED);
        borrowRequestRepository.save(reqApproved);

        // Request 3: Elena borrowed Basketball (APPROVED / BORROWED)
        BorrowRequest reqBasketball = new BorrowRequest(
            item9,
            studentElena,
            LocalDate.now().minusDays(1),
            LocalDate.now().plusDays(2),
            "Inter-dorm weekend basketball tournament practice."
        );
        reqBasketball.setStatus(RequestStatus.APPROVED);
        borrowRequestRepository.save(reqBasketball);

        // Request 4: Past Returned request for history
        BorrowRequest reqReturned = new BorrowRequest(
            item3,
            studentElena,
            LocalDate.now().minusDays(12),
            LocalDate.now().minusDays(5),
            "IoT sensor network workshop assignment."
        );
        reqReturned.setStatus(RequestStatus.RETURNED);
        borrowRequestRepository.save(reqReturned);
    }
}
