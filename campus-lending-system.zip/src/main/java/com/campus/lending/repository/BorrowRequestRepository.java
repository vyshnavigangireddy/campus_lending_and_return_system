package com.campus.lending.repository;

import com.campus.lending.model.BorrowRequest;
import com.campus.lending.model.RequestStatus;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.time.LocalDate;
import java.util.Collection;
import java.util.List;
import java.util.Optional;

@Repository
public interface BorrowRequestRepository extends JpaRepository<BorrowRequest, Long> {

    List<BorrowRequest> findByBorrowerIdOrderByCreatedAtDesc(Long borrowerId);

    List<BorrowRequest> findByItemOwnerIdOrderByCreatedAtDesc(Long ownerId);

    List<BorrowRequest> findByItemOwnerIdAndStatusOrderByCreatedAtDesc(Long ownerId, RequestStatus status);

    List<BorrowRequest> findAllByOrderByCreatedAtDesc();

    List<BorrowRequest> findByStatusOrderByCreatedAtDesc(RequestStatus status);

    List<BorrowRequest> findByStatusAndDueDateAndReminderSentFalse(RequestStatus status, LocalDate dueDate);

    List<BorrowRequest> findByStatusAndDueDateLessThanEqualAndReminderSentFalse(RequestStatus status, LocalDate dueDate);

    List<BorrowRequest> findByStatusInAndDueDateAndReminderSentFalse(Collection<RequestStatus> statuses, LocalDate dueDate);

    List<BorrowRequest> findByStatusInAndDueDateLessThanEqualAndReminderSentFalse(Collection<RequestStatus> statuses, LocalDate dueDate);

    List<BorrowRequest> findByBorrowerIdAndReminderSentTrueOrderByReminderSentAtDesc(Long borrowerId);

    Optional<BorrowRequest> findTopByItemIdAndStatusOrderByCreatedAtDesc(Long itemId, RequestStatus status);

    boolean existsByItemIdAndBorrowerIdAndStatusIn(Long itemId, Long borrowerId, Collection<RequestStatus> statuses);

    long countByStatus(RequestStatus status);

    long countByItemOwnerIdAndStatus(Long ownerId, RequestStatus status);

    long countByBorrowerIdAndStatus(Long borrowerId, RequestStatus status);
}
