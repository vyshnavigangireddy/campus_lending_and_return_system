package com.campus.lending.repository;

import com.campus.lending.model.IntimationNotification;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface IntimationNotificationRepository extends JpaRepository<IntimationNotification, Long> {

    List<IntimationNotification> findByRecipientIdOrderBySentAtDesc(Long recipientId);

    List<IntimationNotification> findAllByOrderBySentAtDesc();

    long countByRecipientId(Long recipientId);
}
