package com.campus.lending.repository;

import com.campus.lending.model.Item;
import com.campus.lending.model.ItemStatus;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface ItemRepository extends JpaRepository<Item, Long> {

    List<Item> findAllByOrderByCreatedAtDesc();

    List<Item> findByOwnerIdOrderByCreatedAtDesc(Long ownerId);

    List<Item> findByCategoryIgnoreCaseOrderByCreatedAtDesc(String category);

    List<Item> findByStatusOrderByCreatedAtDesc(ItemStatus status);

    @Query("SELECT i FROM Item i WHERE " +
           "(:category IS NULL OR :category = '' OR LOWER(i.category) = LOWER(:category)) AND " +
           "(:status IS NULL OR i.status = :status) AND " +
           "(:keyword IS NULL OR :keyword = '' OR LOWER(i.title) LIKE LOWER(CONCAT('%', :keyword, '%')) OR LOWER(i.description) LIKE LOWER(CONCAT('%', :keyword, '%'))) " +
           "ORDER BY i.createdAt DESC")
    List<Item> searchItems(@Param("keyword") String keyword, 
                           @Param("category") String category, 
                           @Param("status") ItemStatus status);

    @Query("SELECT DISTINCT i.category FROM Item i ORDER BY i.category ASC")
    List<String> findDistinctCategories();

    long countByStatus(ItemStatus status);
    
    long countByOwnerId(Long ownerId);
}
