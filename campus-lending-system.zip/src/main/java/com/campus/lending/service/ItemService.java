package com.campus.lending.service;

import com.campus.lending.model.Item;
import com.campus.lending.model.ItemStatus;
import com.campus.lending.model.User;
import com.campus.lending.repository.ItemRepository;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.Arrays;
import java.util.List;
import java.util.Optional;

@Service
@Transactional
public class ItemService {

    private final ItemRepository itemRepository;

    public static final List<String> DEFAULT_CATEGORIES = Arrays.asList(
        "Electronics",
        "Lab Kits",
        "Books & Courseware",
        "Sports Gear",
        "Audio & Visual",
        "Robotics & IoT",
        "Mechanical Tools"
    );

    public ItemService(ItemRepository itemRepository) {
        this.itemRepository = itemRepository;
    }

    public List<Item> getAllItems() {
        return itemRepository.findAllByOrderByCreatedAtDesc();
    }

    public Optional<Item> findById(Long id) {
        return itemRepository.findById(id);
    }

    public List<Item> searchItems(String keyword, String category, ItemStatus status) {
        String cleanKeyword = (keyword != null && !keyword.trim().isEmpty()) ? keyword.trim() : null;
        String cleanCategory = (category != null && !category.trim().isEmpty() && !category.equalsIgnoreCase("ALL")) ? category.trim() : null;
        return itemRepository.searchItems(cleanKeyword, cleanCategory, status);
    }

    public List<Item> findByOwner(Long ownerId) {
        return itemRepository.findByOwnerIdOrderByCreatedAtDesc(ownerId);
    }

    public List<String> getAvailableCategories() {
        List<String> dbCategories = itemRepository.findDistinctCategories();
        if (dbCategories == null || dbCategories.isEmpty()) {
            return DEFAULT_CATEGORIES;
        }
        for (String def : DEFAULT_CATEGORIES) {
            if (!dbCategories.contains(def)) {
                dbCategories.add(def);
            }
        }
        return dbCategories;
    }

    public Item saveItem(Item item, User owner) {
        item.setOwner(owner);
        return itemRepository.save(item);
    }

    public Item updateItem(Long id, String title, String category, String description, String imageUrl, User requester) {
        Item item = itemRepository.findById(id)
            .orElseThrow(() -> new IllegalArgumentException("Item not found with id: " + id));

        // Check ownership or admin
        if (!item.getOwner().getId().equals(requester.getId()) && !requester.isAdmin() && !requester.isApprover()) {
            throw new SecurityException("Unauthorized: You can only edit items you own.");
        }

        item.setTitle(title);
        item.setCategory(category);
        item.setDescription(description);
        if (imageUrl != null && !imageUrl.trim().isEmpty()) {
            item.setImageUrl(imageUrl.trim());
        }
        return itemRepository.save(item);
    }

    public void deleteItem(Long id, User requester) {
        Item item = itemRepository.findById(id)
            .orElseThrow(() -> new IllegalArgumentException("Item not found with id: " + id));

        if (!item.getOwner().getId().equals(requester.getId()) && !requester.isAdmin() && !requester.isApprover()) {
            throw new SecurityException("Unauthorized: You can only delete items you own.");
        }

        if (item.getStatus() == ItemStatus.BORROWED) {
            throw new IllegalStateException("Cannot delete an item that is currently borrowed. Please wait until it is returned.");
        }

        itemRepository.delete(item);
    }

    public Item setItemStatus(Long id, ItemStatus status) {
        Item item = itemRepository.findById(id)
            .orElseThrow(() -> new IllegalArgumentException("Item not found with id: " + id));
        item.setStatus(status);
        return itemRepository.save(item);
    }

    public long countTotalItems() {
        return itemRepository.count();
    }

    public long countAvailableItems() {
        return itemRepository.countByStatus(ItemStatus.AVAILABLE);
    }

    public long countBorrowedItems() {
        return itemRepository.countByStatus(ItemStatus.BORROWED);
    }
}
