package com.campus.lending.service;

import com.campus.lending.model.*;
import com.campus.lending.repository.BorrowRequestRepository;
import com.campus.lending.repository.ItemRepository;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDate;
import java.util.Arrays;
import java.util.List;
import java.util.Optional;

@Service
@Transactional
public class BorrowRequestService {

    private final BorrowRequestRepository borrowRequestRepository;
    private final ItemRepository itemRepository;

    public BorrowRequestService(BorrowRequestRepository borrowRequestRepository, ItemRepository itemRepository) {
        this.borrowRequestRepository = borrowRequestRepository;
        this.itemRepository = itemRepository;
    }

    public BorrowRequest createRequest(Long itemId, User borrower, LocalDate borrowDate, LocalDate dueDate, String purpose) {
        Item item = itemRepository.findById(itemId)
            .orElseThrow(() -> new IllegalArgumentException("Item not found with id: " + itemId));

        if (item.getStatus() != ItemStatus.AVAILABLE) {
            throw new IllegalStateException("Item '" + item.getTitle() + "' is currently borrowed and unavailable.");
        }

        if (dueDate.isBefore(borrowDate)) {
            throw new IllegalArgumentException("Due date cannot be earlier than the borrow start date.");
        }

        // Check if user already has an active pending, approved, or loaned request for this item
        boolean hasActiveRequest = borrowRequestRepository.existsByItemIdAndBorrowerIdAndStatusIn(
            itemId, borrower.getId(), Arrays.asList(RequestStatus.PENDING, RequestStatus.APPROVED, RequestStatus.LOANED)
        );
        if (hasActiveRequest) {
            throw new IllegalStateException("You already have an active or pending request for this item.");
        }

        BorrowRequest request = new BorrowRequest(item, borrower, borrowDate, dueDate, purpose != null ? purpose.trim() : "");
        return borrowRequestRepository.save(request);
    }

    public BorrowRequest updateRequest(Long requestId, LocalDate borrowDate, LocalDate dueDate, String purpose, User requester) {
        BorrowRequest request = borrowRequestRepository.findById(requestId)
            .orElseThrow(() -> new IllegalArgumentException("Request not found with id: " + requestId));

        if (!request.getBorrower().getId().equals(requester.getId()) && !requester.isAdmin()) {
            throw new SecurityException("Unauthorized: You can only edit your own borrow requests.");
        }

        if (request.getStatus() != RequestStatus.PENDING) {
            throw new IllegalStateException("Only pending requests can be modified.");
        }

        if (dueDate.isBefore(borrowDate)) {
            throw new IllegalArgumentException("Due date cannot be earlier than the borrow start date.");
        }

        request.setBorrowDate(borrowDate);
        request.setDueDate(dueDate);
        request.setPurpose(purpose != null ? purpose.trim() : "");
        return borrowRequestRepository.save(request);
    }

    public void cancelRequest(Long requestId, User requester) {
        BorrowRequest request = borrowRequestRepository.findById(requestId)
            .orElseThrow(() -> new IllegalArgumentException("Request not found with id: " + requestId));

        if (!request.getBorrower().getId().equals(requester.getId()) && !requester.isAdmin()) {
            throw new SecurityException("Unauthorized: You can only cancel your own borrow requests.");
        }

        if (request.getStatus() != RequestStatus.PENDING) {
            throw new IllegalStateException("Only pending requests can be cancelled.");
        }

        borrowRequestRepository.delete(request);
    }

    public BorrowRequest approveRequest(Long requestId, User approver) {
        BorrowRequest request = borrowRequestRepository.findById(requestId)
            .orElseThrow(() -> new IllegalArgumentException("Request not found with id: " + requestId));

        // Approver must be the item owner OR have APPROVER / ADMIN role
        boolean isOwner = request.getItem().getOwner().getId().equals(approver.getId());
        if (!isOwner && !approver.isApprover() && !approver.isAdmin()) {
            throw new SecurityException("Unauthorized: Only the item lender or an authorized approver can approve this request.");
        }

        if (request.getStatus() != RequestStatus.PENDING) {
            throw new IllegalStateException("Request is already " + request.getStatus() + ".");
        }

        Item item = request.getItem();
        if (item.getStatus() != ItemStatus.AVAILABLE) {
            throw new IllegalStateException("This item has already been marked as borrowed.");
        }

        request.setStatus(RequestStatus.APPROVED);
        item.setStatus(ItemStatus.BORROWED);
        itemRepository.save(item);

        return borrowRequestRepository.save(request);
    }

    public BorrowRequest confirmHandover(Long requestId, User labIncharge) {
        BorrowRequest request = borrowRequestRepository.findById(requestId)
            .orElseThrow(() -> new IllegalArgumentException("Request not found with id: " + requestId));

        boolean isOwner = request.getItem().getOwner().getId().equals(labIncharge.getId());
        boolean isAuthorized = isOwner || labIncharge.isLabIncharge() || labIncharge.isLender() || labIncharge.isAdmin();
        if (!isAuthorized) {
            throw new SecurityException("Unauthorized: Only the Lab Incharge or equipment owner can confirm physical handover of this item.");
        }

        if (request.getStatus() != RequestStatus.APPROVED) {
            throw new IllegalStateException("Only approved requests awaiting pickup can be marked as item issued / given.");
        }

        request.setStatus(RequestStatus.LOANED);
        request.setHandoverConfirmedAt(java.time.LocalDateTime.now());
        return borrowRequestRepository.save(request);
    }

    public BorrowRequest revertToAwaitingPickup(Long requestId, User labIncharge) {
        BorrowRequest request = borrowRequestRepository.findById(requestId)
            .orElseThrow(() -> new IllegalArgumentException("Request not found with id: " + requestId));

        boolean isOwner = request.getItem().getOwner().getId().equals(labIncharge.getId());
        boolean isAuthorized = isOwner || labIncharge.isLabIncharge() || labIncharge.isLender() || labIncharge.isAdmin();
        if (!isAuthorized) {
            throw new SecurityException("Unauthorized: Only the Lab Incharge or equipment owner can update item status.");
        }

        if (request.getStatus() != RequestStatus.LOANED) {
            throw new IllegalStateException("Only issued items can be reset back to awaiting pickup.");
        }

        request.setStatus(RequestStatus.APPROVED);
        request.setHandoverConfirmedAt(null);
        return borrowRequestRepository.save(request);
    }

    public BorrowRequest declineRequest(Long requestId, User approver) {
        BorrowRequest request = borrowRequestRepository.findById(requestId)
            .orElseThrow(() -> new IllegalArgumentException("Request not found with id: " + requestId));

        boolean isOwner = request.getItem().getOwner().getId().equals(approver.getId());
        if (!isOwner && !approver.isApprover() && !approver.isAdmin()) {
            throw new SecurityException("Unauthorized: Only the Lab Incharge or an authorized approver can decline this request.");
        }

        if (request.getStatus() != RequestStatus.PENDING) {
            throw new IllegalStateException("Request is already " + request.getStatus() + ".");
        }

        request.setStatus(RequestStatus.REJECTED);
        return borrowRequestRepository.save(request);
    }

    public BorrowRequest returnItem(Long requestId, User requester) {
        BorrowRequest request = borrowRequestRepository.findById(requestId)
            .orElseThrow(() -> new IllegalArgumentException("Request not found with id: " + requestId));

        // Strict security: ONLY the Lab Incharge (or item owner / admin) can confirm physical return!
        boolean isOwner = request.getItem().getOwner().getId().equals(requester.getId());
        boolean isAuthorized = isOwner || requester.isLabIncharge() || requester.isLender() || requester.isAdmin();
        if (!isAuthorized) {
            throw new SecurityException("Unauthorized: Only the Lab Incharge can confirm physical return of the item once received in the lab.");
        }

        if (request.getStatus() != RequestStatus.APPROVED && request.getStatus() != RequestStatus.LOANED) {
            throw new IllegalStateException("Only approved or loaned items can be marked as returned.");
        }

        request.setStatus(RequestStatus.RETURNED);
        Item item = request.getItem();
        item.setStatus(ItemStatus.AVAILABLE);
        itemRepository.save(item);

        return borrowRequestRepository.save(request);
    }

    public BorrowRequest extendLoan(Long requestId, LocalDate newDueDate, String reason, User student) {
        BorrowRequest request = borrowRequestRepository.findById(requestId)
            .orElseThrow(() -> new IllegalArgumentException("Request not found with id: " + requestId));

        if (!request.getBorrower().getId().equals(student.getId()) && !student.isAdmin()) {
            throw new SecurityException("Unauthorized: You can only extend return dates for your own borrowed items.");
        }

        if (request.getStatus() != RequestStatus.APPROVED && request.getStatus() != RequestStatus.LOANED) {
            throw new IllegalStateException("Only active or approved loans can be extended.");
        }

        if (newDueDate.isBefore(request.getDueDate()) || newDueDate.isEqual(request.getDueDate())) {
            throw new IllegalArgumentException("New return date must be later than the current due date (" + request.getDueDate() + ").");
        }

        request.setDueDate(newDueDate);
        request.setExtensionReason(reason != null ? reason.trim() : "Coursework extension requested by student");
        request.setExtended(true);
        // Reset reminderSent flag so the student receives a fresh intimation 1 day before the new due date
        request.setReminderSent(false);

        return borrowRequestRepository.save(request);
    }

    public Optional<BorrowRequest> findById(Long id) {
        return borrowRequestRepository.findById(id);
    }

    public List<BorrowRequest> getRequestsByBorrower(Long borrowerId) {
        return borrowRequestRepository.findByBorrowerIdOrderByCreatedAtDesc(borrowerId);
    }

    public List<BorrowRequest> getRequestsForLender(Long ownerId) {
        return borrowRequestRepository.findByItemOwnerIdOrderByCreatedAtDesc(ownerId);
    }

    public List<BorrowRequest> getAllRequests() {
        return borrowRequestRepository.findAllByOrderByCreatedAtDesc();
    }

    public long countPending() {
        return borrowRequestRepository.countByStatus(RequestStatus.PENDING);
    }

    public long countApproved() {
        return borrowRequestRepository.countByStatus(RequestStatus.APPROVED);
    }

    public long countReturned() {
        return borrowRequestRepository.countByStatus(RequestStatus.RETURNED);
    }

    public long countPendingForLender(Long ownerId) {
        return borrowRequestRepository.countByItemOwnerIdAndStatus(ownerId, RequestStatus.PENDING);
    }

    public long countActiveForBorrower(Long borrowerId) {
        return borrowRequestRepository.countByBorrowerIdAndStatus(borrowerId, RequestStatus.APPROVED);
    }
}
