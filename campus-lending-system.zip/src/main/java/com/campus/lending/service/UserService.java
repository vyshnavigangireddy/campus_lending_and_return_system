package com.campus.lending.service;

import com.campus.lending.model.Role;
import com.campus.lending.model.User;
import com.campus.lending.repository.UserRepository;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.Optional;
import java.util.regex.Pattern;

@Service
@Transactional
public class UserService {

    // Strict RFC 5322 & campus institutional email validation pattern
    private static final Pattern EMAIL_PATTERN = Pattern.compile(
        "^[a-zA-Z0-9_+&*-]+(?:\\.[a-zA-Z0-9_+&*-]+)*@(?:[a-zA-Z0-9-]+\\.)+[a-zA-Z]{2,10}$"
    );

    private final UserRepository userRepository;

    public UserService(UserRepository userRepository) {
        this.userRepository = userRepository;
    }

    /**
     * Checks if the given email is a proper, valid institutional or domain email ID.
     */
    public boolean isValidEmail(String email) {
        return getEmailValidationError(email) == null;
    }

    /**
     * Returns a human-friendly error message if the email is improper, or null if valid.
     */
    public String getEmailValidationError(String email) {
        if (email == null || email.trim().isEmpty()) {
            return "Email address cannot be empty. Please enter your proper campus email ID.";
        }
        String trimmed = email.trim();
        if (trimmed.contains(" ")) {
            return "Email address cannot contain spaces.";
        }
        if (!trimmed.contains("@")) {
            return "Missing '@' symbol in email. Please enter a proper mail ID (e.g., student@college.edu).";
        }
        int atIndex = trimmed.indexOf('@');
        int lastAtIndex = trimmed.lastIndexOf('@');
        if (atIndex != lastAtIndex) {
            return "Email cannot contain multiple '@' symbols.";
        }
        String localPart = trimmed.substring(0, atIndex);
        String domainPart = trimmed.substring(atIndex + 1);

        if (localPart.isEmpty()) {
            return "Missing username before '@'. Please enter a proper mail ID (e.g., student@college.edu).";
        }
        if (domainPart.isEmpty() || !domainPart.contains(".")) {
            return "Missing valid domain extension (e.g., .edu, .ac.in, .org). A proper mail ID is required.";
        }
        if (domainPart.startsWith(".") || domainPart.endsWith(".")) {
            return "Domain cannot start or end with a dot.";
        }
        if (domainPart.contains("..")) {
            return "Domain cannot contain consecutive dots.";
        }
        String[] domainTokens = domainPart.split("\\.");
        String tld = domainTokens[domainTokens.length - 1];
        if (tld.length() < 2 || !tld.matches("^[a-zA-Z]+$")) {
            return "Top-level domain extension must be at least 2 letters (e.g., .edu, .org, .com).";
        }
        if (!EMAIL_PATTERN.matcher(trimmed).matches()) {
            return "Improper mail ID format. Access denied: Please enter a proper campus email (e.g., student@college.edu, lender@college.edu, approver@college.edu).";
        }
        return null;
    }

    public User authenticateOrRegister(String email, String customName, Role chosenRole) {
        String validationError = getEmailValidationError(email);
        if (validationError != null) {
            throw new IllegalArgumentException("Access Denied: " + validationError);
        }

        String normalizedEmail = email.trim().toLowerCase();
        Optional<User> existingUser = userRepository.findByEmailIgnoreCase(normalizedEmail);

        if (existingUser.isPresent()) {
            User user = existingUser.get();
            // If user explicitly changed role during login or updated their profile
            if (chosenRole != null && user.getRole() != chosenRole && chosenRole != Role.STUDENT) {
                user.setRole(chosenRole);
                return userRepository.save(user);
            }
            return user;
        }

        // New user registration
        String derivedName = customName;
        if (derivedName == null || derivedName.trim().isEmpty()) {
            derivedName = deriveNameFromEmail(normalizedEmail);
        }

        Role role = chosenRole != null ? chosenRole : Role.STUDENT;
        User newUser = new User(derivedName.trim(), normalizedEmail, role);
        return userRepository.save(newUser);
    }

    public Optional<User> findById(Long id) {
        return userRepository.findById(id);
    }

    public Optional<User> findByEmail(String email) {
        if (email == null) return Optional.empty();
        return userRepository.findByEmailIgnoreCase(email.trim().toLowerCase());
    }

    public List<User> findAllUsers() {
        return userRepository.findAll();
    }

    public User save(User user) {
        return userRepository.save(user);
    }

    private String deriveNameFromEmail(String email) {
        String prefix = email.split("@")[0];
        // Replace dots, underscores, dashes with space and capitalize
        String[] tokens = prefix.split("[._-]+");
        StringBuilder sb = new StringBuilder();
        for (String token : tokens) {
            if (!token.isEmpty()) {
                sb.append(Character.toUpperCase(token.charAt(0)));
                if (token.length() > 1) {
                    sb.append(token.substring(1).toLowerCase());
                }
                sb.append(" ");
            }
        }
        String name = sb.toString().trim();
        return name.isEmpty() ? "Campus Member" : name;
    }
}
