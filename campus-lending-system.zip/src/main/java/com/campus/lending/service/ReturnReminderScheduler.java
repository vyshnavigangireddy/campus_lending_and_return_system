package com.campus.lending.service;

import com.campus.lending.model.BorrowRequest;
import com.campus.lending.model.RequestStatus;
import com.campus.lending.repository.BorrowRequestRepository;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.List;

@Service
@Transactional
public class ReturnReminderScheduler {

    private static final Logger log = LoggerFactory.getLogger(ReturnReminderScheduler.class);

    private final BorrowRequestRepository borrowRequestRepository;
    private final EmailNotificationService emailNotificationService;

    public ReturnReminderScheduler(BorrowRequestRepository borrowRequestRepository,
                                  EmailNotificationService emailNotificationService) {
        this.borrowRequestRepository = borrowRequestRepository;
        this.emailNotificationService = emailNotificationService;
    }

    /**
     * Automated schedule: Runs daily at 08:00 AM (server time).
     */
    @Scheduled(cron = "0 0 8 * * ?")
    public void runDailyMorningReminders() {
        log.info("[SCHEDULER] Running daily 08:00 AM 1-day return intimation check...");
        checkAndSendDueReminders();
    }

    /**
     * Periodic background sweep: Runs every hour to check for upcoming 1-day return deadlines.
     */
    @Scheduled(fixedDelay = 3600000, initialDelay = 30000)
    public void runHourlySweep() {
        log.info("[SCHEDULER] Running periodic check for 1-day return intimations...");
        checkAndSendDueReminders();
    }

    /**
     * Checks all actively borrowed items and dispatches an intimation mail to the student
     * exactly 1 day before the return date (due_date == today + 1 day).
     *
     * @return count of intimations successfully sent
     */
    public int checkAndSendDueReminders() {
        LocalDate tomorrow = LocalDate.now().plusDays(1);
        log.info("[INTIMATION SCAN] Looking for active loans due tomorrow: {}", tomorrow);

        java.util.List<RequestStatus> activeStatuses = java.util.Arrays.asList(RequestStatus.APPROVED, RequestStatus.LOANED);

        // Find active loans due tomorrow that haven't received a reminder yet
        List<BorrowRequest> dueTomorrow = borrowRequestRepository
                .findByStatusInAndDueDateAndReminderSentFalse(activeStatuses, tomorrow);

        // Also check if any active loan is due today or overdue and never received a reminder
        List<BorrowRequest> dueTodayOrPast = borrowRequestRepository
                .findByStatusInAndDueDateLessThanEqualAndReminderSentFalse(activeStatuses, LocalDate.now());

        int count = 0;

        for (BorrowRequest req : dueTomorrow) {
            try {
                emailNotificationService.sendDueDateIntimation(req);
                req.setReminderSent(true);
                req.setReminderSentAt(LocalDateTime.now());
                borrowRequestRepository.save(req);
                count++;
                log.info("[INTIMATION DISPATCHED] 1-day reminder sent to {} for item '{}' (Due: {})",
                        req.getBorrower().getEmail(), req.getItem().getTitle(), req.getDueDate());
            } catch (Exception ex) {
                log.error("[INTIMATION ERROR] Failed to send reminder for request ID {}: {}", req.getId(), ex.getMessage(), ex);
            }
        }

        for (BorrowRequest req : dueTodayOrPast) {
            try {
                emailNotificationService.sendDueDateIntimation(req);
                req.setReminderSent(true);
                req.setReminderSentAt(LocalDateTime.now());
                borrowRequestRepository.save(req);
                count++;
                log.info("[URGENT INTIMATION DISPATCHED] Due/overdue reminder sent to {} for item '{}' (Due: {})",
                        req.getBorrower().getEmail(), req.getItem().getTitle(), req.getDueDate());
            } catch (Exception ex) {
                log.error("[INTIMATION ERROR] Failed to send overdue reminder for request ID {}: {}", req.getId(), ex.getMessage(), ex);
            }
        }

        log.info("[INTIMATION SCAN COMPLETE] Total 1-day intimation reminders sent: {}", count);
        return count;
    }

    /**
     * On-demand simulation: Sends a 1-day intimation email for a specific request.
     */
    public boolean sendManualIntimation(Long requestId) {
        BorrowRequest req = borrowRequestRepository.findById(requestId).orElse(null);
        if (req != null && (req.getStatus() == RequestStatus.APPROVED || req.getStatus() == RequestStatus.LOANED)) {
            emailNotificationService.sendDueDateIntimation(req);
            req.setReminderSent(true);
            req.setReminderSentAt(LocalDateTime.now());
            borrowRequestRepository.save(req);
            return true;
        }
        return false;
    }
}
