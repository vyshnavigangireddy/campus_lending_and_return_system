package com.campus.lending.service;

import com.campus.lending.model.BorrowRequest;
import com.campus.lending.model.IntimationNotification;
import com.campus.lending.model.User;
import com.campus.lending.repository.IntimationNotificationRepository;
import jakarta.mail.internet.MimeMessage;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.ObjectProvider;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.mail.javamail.MimeMessageHelper;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.List;

@Service
@Transactional
public class EmailNotificationService {

    private static final Logger log = LoggerFactory.getLogger(EmailNotificationService.class);

    private final ObjectProvider<JavaMailSender> mailSenderProvider;
    private final IntimationNotificationRepository intimationNotificationRepository;

    @Value("${campus.mail.enabled:false}")
    private boolean mailEnabled;

    @Value("${campus.mail.sender:noreply@college.edu}")
    private String senderEmail;

    public EmailNotificationService(ObjectProvider<JavaMailSender> mailSenderProvider,
                                  IntimationNotificationRepository intimationNotificationRepository) {
        this.mailSenderProvider = mailSenderProvider;
        this.intimationNotificationRepository = intimationNotificationRepository;
    }

    /**
     * Dispatches an intimation reminder email to a student 1 day before their item return date.
     */
    public IntimationNotification sendDueDateIntimation(BorrowRequest request) {
        User borrower = request.getBorrower();
        String itemTitle = request.getItem().getTitle();
        String category = request.getItem().getCategory();
        LocalDate dueDate = request.getDueDate();
        String formattedDueDate = dueDate.format(DateTimeFormatter.ofPattern("MMM dd, yyyy"));
        String lenderName = request.getItem().getOwner().getName();
        String lenderEmail = request.getItem().getOwner().getEmail();

        String subject = "⏰ Return Reminder: \"" + itemTitle + "\" is due tomorrow (" + formattedDueDate + ")";
        String htmlContent = buildIntimationHtml(borrower.getName(), itemTitle, category, formattedDueDate, lenderName, lenderEmail);

        String deliveryStatus = "RECORDED_IN_APP";

        JavaMailSender mailSender = mailSenderProvider.getIfAvailable();
        if (mailEnabled && mailSender != null) {
            try {
                MimeMessage mimeMessage = mailSender.createMimeMessage();
                MimeMessageHelper helper = new MimeMessageHelper(mimeMessage, "utf-8");
                helper.setFrom(senderEmail);
                helper.setTo(borrower.getEmail());
                helper.setSubject(subject);
                helper.setText(htmlContent, true);
                mailSender.send(mimeMessage);
                deliveryStatus = "DELIVERED_SMTP";
                log.info("[SMTP SUCCESS] Dispatched intimation email to {} for item '{}'", borrower.getEmail(), itemTitle);
            } catch (Exception ex) {
                log.warn("[SMTP FALLBACK] Could not deliver live SMTP email to {}: {}. Recorded in intimation logs.",
                        borrower.getEmail(), ex.getMessage());
                deliveryStatus = "DISPATCHED_FALLBACK";
            }
        } else {
            log.info("[INTIMATION NOTICE] Simulated 1-day reminder email to {} for '{}' (Due: {})",
                    borrower.getEmail(), itemTitle, formattedDueDate);
            deliveryStatus = "ACTIVE_SIMULATED";
        }

        IntimationNotification notification = new IntimationNotification(
                request,
                borrower,
                itemTitle,
                dueDate,
                subject,
                htmlContent,
                deliveryStatus
        );

        return intimationNotificationRepository.save(notification);
    }

    public List<IntimationNotification> getNotificationsForUser(Long userId) {
        return intimationNotificationRepository.findByRecipientIdOrderBySentAtDesc(userId);
    }

    public List<IntimationNotification> getAllNotifications() {
        return intimationNotificationRepository.findAllByOrderBySentAtDesc();
    }

    private String buildIntimationHtml(String studentName, String itemTitle, String category,
                                       String dueDate, String lenderName, String lenderEmail) {
        return "<!DOCTYPE html>"
                + "<html><head><meta charset='UTF-8'></head>"
                + "<body style=\"font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, Helvetica, Arial, sans-serif; background-color: #f8fafc; margin: 0; padding: 24px;\">"
                + "<div style=\"max-width: 600px; margin: 0 auto; background: #ffffff; border-radius: 14px; border: 1px solid #e2e8f0; overflow: hidden; box-shadow: 0 10px 25px -5px rgba(0, 0, 0, 0.05);\">"
                + "  <div style=\"background: linear-gradient(135deg, #4f46e5 0%, #6366f1 100%); padding: 28px 24px; text-align: center; color: #ffffff;\">"
                + "    <h1 style=\"margin: 0; font-size: 20px; font-weight: 800; letter-spacing: -0.01em;\">Campus Item Lending &amp; Return System</h1>"
                + "    <p style=\"margin: 6px 0 0; font-size: 13px; opacity: 0.9;\">University Equipment &amp; Resource Hub</p>"
                + "  </div>"
                + "  <div style=\"padding: 28px 24px;\">"
                + "    <div style=\"background: #fffbeb; border: 1px solid #fde68a; border-radius: 10px; padding: 14px 18px; margin-bottom: 22px;\">"
                + "      <div style=\"display: flex; align-items: center;\">"
                + "        <strong style=\"color: #92400e; font-size: 15px;\">⏰ 1-Day Return Intimation Notice</strong>"
                + "      </div>"
                + "      <p style=\"margin: 4px 0 0; color: #b45309; font-size: 13px;\">Your borrowed campus gear is scheduled for return tomorrow.</p>"
                + "    </div>"
                + "    <p style=\"color: #334155; font-size: 15px; line-height: 1.6; margin-top: 0;\">"
                + "      Hello <strong>" + escape(studentName) + "</strong>,"
                + "    </p>"
                + "    <p style=\"color: #475569; font-size: 14px; line-height: 1.6;\">"
                + "      This is an automated intimation reminder from the campus resource portal. You have an active loan that is due for return tomorrow."
                + "    </p>"
                + "    <table style=\"width: 100%; border-collapse: collapse; margin: 20px 0; font-size: 14px;\">"
                + "      <tr style=\"border-bottom: 1px solid #f1f5f9;\">"
                + "        <td style=\"padding: 10px 0; color: #64748b; font-weight: 600;\">Equipment Title:</td>"
                + "        <td style=\"padding: 10px 0; color: #0f172a; font-weight: 700; text-align: right;\">" + escape(itemTitle) + "</td>"
                + "      </tr>"
                + "      <tr style=\"border-bottom: 1px solid #f1f5f9;\">"
                + "        <td style=\"padding: 10px 0; color: #64748b; font-weight: 600;\">Category:</td>"
                + "        <td style=\"padding: 10px 0; color: #4f46e5; font-weight: 600; text-align: right;\">" + escape(category) + "</td>"
                + "      </tr>"
                + "      <tr style=\"border-bottom: 1px solid #f1f5f9;\">"
                + "        <td style=\"padding: 10px 0; color: #64748b; font-weight: 600;\">Return Deadline:</td>"
                + "        <td style=\"padding: 10px 0; color: #d97706; font-weight: 700; text-align: right;\">" + escape(dueDate) + " (Tomorrow)</td>"
                + "      </tr>"
                + "      <tr style=\"border-bottom: 1px solid #f1f5f9;\">"
                + "        <td style=\"padding: 10px 0; color: #64748b; font-weight: 600;\">Lab Incharge:</td>"
                + "        <td style=\"padding: 10px 0; color: #0f172a; font-weight: 600; text-align: right;\">" + escape(lenderName) + " (" + escape(lenderEmail) + ")</td>"
                + "      </tr>"
                + "    </table>"
                + "    <div style=\"background: #eef2ff; border: 1px solid #c7d2fe; border-radius: 8px; padding: 14px 18px; margin-bottom: 20px;\">"
                + "      <strong style=\"color: #4338ca; font-size: 13px; display: block; margin-bottom: 4px;\">⏱️ Need More Days for Your Project?</strong>"
                + "      <p style=\"margin: 0; color: #3730a3; font-size: 13px; line-height: 1.5;\">"
                + "        If your experiment or capstone requires additional time, you can <strong>extend your return date</strong> directly on your student dashboard before the deadline."
                + "      </p>"
                + "    </div>"
                + "    <div style=\"background: #f8fafc; border-radius: 8px; border: 1px solid #e2e8f0; padding: 14px 18px; margin-bottom: 24px;\">"
                + "      <strong style=\"color: #1e293b; font-size: 13px; display: block; margin-bottom: 6px;\">📋 Return Checklist:</strong>"
                + "      <ul style=\"margin: 0; padding-left: 20px; color: #475569; font-size: 13px; line-height: 1.6;\">"
                + "        <li>Inspect gear to make sure all components, probes, and power supplies are included.</li>"
                + "        <li>Hand over the item directly to the <strong>Lab Incharge</strong> at the department lab.</li>"
                + "        <li>Only the Lab Incharge can inspect and confirm the physical return of this equipment.</li>"
                + "      </ul>"
                + "    </div>"
                + "    <p style=\"color: #64748b; font-size: 12px; margin-top: 24px; text-align: center; border-top: 1px solid #e2e8f0; padding-top: 16px;\">"
                + "      Campus Item Lending &amp; Return System &bull; Automated Governance Service"
                + "    </p>"
                + "  </div>"
                + "</div>"
                + "</body></html>";
    }

    private String escape(String text) {
        if (text == null) return "";
        return text.replace("&", "&amp;")
                .replace("<", "&lt;")
                .replace(">", "&gt;")
                .replace("\"", "&quot;");
    }
}
