package com.campus.lending.controller;

import com.campus.lending.dto.BorrowRequestDto;
import com.campus.lending.dto.ItemDto;
import com.campus.lending.model.Item;
import com.campus.lending.model.ItemStatus;
import com.campus.lending.service.BorrowRequestService;
import com.campus.lending.service.ItemService;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;

import java.util.List;

@Controller
public class CatalogController {

    private final ItemService itemService;
    private final BorrowRequestService borrowRequestService;

    public CatalogController(ItemService itemService, BorrowRequestService borrowRequestService) {
        this.itemService = itemService;
        this.borrowRequestService = borrowRequestService;
    }

    @GetMapping("/")
    public String rootRedirect() {
        return "redirect:/catalog";
    }

    @GetMapping("/catalog")
    public String showCatalog(@RequestParam(value = "keyword", required = false) String keyword,
                              @RequestParam(value = "category", required = false) String category,
                              @RequestParam(value = "status", required = false) ItemStatus status,
                              Model model) {

        List<Item> items = itemService.searchItems(keyword, category, status);
        List<String> categories = itemService.getAvailableCategories();

        model.addAttribute("items", items);
        model.addAttribute("categories", categories);
        model.addAttribute("selectedCategory", category != null ? category : "ALL");
        model.addAttribute("selectedStatus", status != null ? status.name() : "ALL");
        model.addAttribute("searchKeyword", keyword != null ? keyword : "");
        model.addAttribute("totalCount", items.size());
        model.addAttribute("availableCount", itemService.countAvailableItems());
        model.addAttribute("borrowedCount", itemService.countBorrowedItems());
        model.addAttribute("totalCatalogItems", itemService.countTotalItems());

        // Prepopulate empty DTOs for the modals
        model.addAttribute("borrowDto", new BorrowRequestDto());
        model.addAttribute("newItemDto", new ItemDto());

        return "catalog/catalog";
    }
}
