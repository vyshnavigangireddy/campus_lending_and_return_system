package com.campus.lending.controller;

import com.campus.lending.dto.BorrowRequestDto;
import com.campus.lending.model.User;
import com.campus.lending.service.BorrowRequestService;
import jakarta.servlet.http.HttpSession;
import jakarta.validation.Valid;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import java.time.LocalDate;

@Controller
@RequestMapping("/requests")
public class BorrowRequestController {

    private final BorrowRequestService borrowRequestService;

    public BorrowRequestController(BorrowRequestService borrowRequestService) {
        this.borrowRequestService = borrowRequestService;
    }

    @PostMapping("/borrow")
    public String submitBorrowRequest(@Valid @ModelAttribute("borrowDto") BorrowRequestDto borrowDto,
                                      BindingResult bindingResult,
                                      @RequestParam(value = "redirectUrl", required = false) String redirectUrl,
                                      HttpSession session,
                                      RedirectAttributes redirectAttributes) {

        User currentUser = (User) session.getAttribute("currentUser");
        if (currentUser == null) {
            redirectAttributes.addFlashAttribute("errorMessage", "Please sign in with your campus email to request an item.");
            return "redirect:/login";
        }

        String fallbackRedirect = (redirectUrl != null && !redirectUrl.isBlank()) ? redirectUrl : "/catalog";

        if (bindingResult.hasErrors()) {
            redirectAttributes.addFlashAttribute("errorMessage",
                bindingResult.getAllErrors().get(0).getDefaultMessage());
            return "redirect:" + fallbackRedirect;
        }

        try {
            borrowRequestService.createRequest(
                borrowDto.getItemId(),
                currentUser,
                borrowDto.getBorrowDate(),
                borrowDto.getDueDate(),
                borrowDto.getPurpose()
            );
            redirectAttributes.addFlashAttribute("successMessage",
                "Lending request submitted! Your request is pending approval.");
            return "redirect:" + (redirectUrl != null && !redirectUrl.isBlank() ? redirectUrl : "/dashboard");
        } catch (Exception ex) {
            redirectAttributes.addFlashAttribute("errorMessage", ex.getMessage());
            return "redirect:" + fallbackRedirect;
        }
    }

    @PostMapping("/{id}/edit")
    public String editPendingRequest(@PathVariable("id") Long id,
                                     @RequestParam("borrowDate") LocalDate borrowDate,
                                     @RequestParam("dueDate") LocalDate dueDate,
                                     @RequestParam(value = "purpose", required = false) String purpose,
                                     HttpSession session,
                                     RedirectAttributes redirectAttributes) {

        User currentUser = (User) session.getAttribute("currentUser");
        if (currentUser == null) {
            return "redirect:/login";
        }

        try {
            borrowRequestService.updateRequest(id, borrowDate, dueDate, purpose, currentUser);
            redirectAttributes.addFlashAttribute("successMessage", "Request updated successfully.");
        } catch (Exception ex) {
            redirectAttributes.addFlashAttribute("errorMessage", ex.getMessage());
        }

        return "redirect:/dashboard";
    }

    @PostMapping("/{id}/cancel")
    public String cancelPendingRequest(@PathVariable("id") Long id,
                                       HttpSession session,
                                       RedirectAttributes redirectAttributes) {

        User currentUser = (User) session.getAttribute("currentUser");
        if (currentUser == null) {
            return "redirect:/login";
        }

        try {
            borrowRequestService.cancelRequest(id, currentUser);
            redirectAttributes.addFlashAttribute("successMessage", "Request cancelled and removed.");
        } catch (Exception ex) {
            redirectAttributes.addFlashAttribute("errorMessage", ex.getMessage());
        }

        return "redirect:/dashboard";
    }

    @PostMapping("/{id}/approve")
    public String approveRequest(@PathVariable("id") Long id,
                                 HttpSession session,
                                 RedirectAttributes redirectAttributes) {

        User currentUser = (User) session.getAttribute("currentUser");
        if (currentUser == null) {
            return "redirect:/login";
        }

        try {
            borrowRequestService.approveRequest(id, currentUser);
            redirectAttributes.addFlashAttribute("successMessage", "Request approved! Status is now 'Awaiting Pickup'.");
        } catch (Exception ex) {
            redirectAttributes.addFlashAttribute("errorMessage", ex.getMessage());
        }

        return "redirect:/dashboard";
    }

    @PostMapping("/{id}/decline")
    public String declineRequest(@PathVariable("id") Long id,
                                 HttpSession session,
                                 RedirectAttributes redirectAttributes) {

        User currentUser = (User) session.getAttribute("currentUser");
        if (currentUser == null) {
            return "redirect:/login";
        }

        try {
            borrowRequestService.declineRequest(id, currentUser);
            redirectAttributes.addFlashAttribute("successMessage", "Request declined.");
        } catch (Exception ex) {
            redirectAttributes.addFlashAttribute("errorMessage", ex.getMessage());
        }

        return "redirect:/dashboard";
    }

    @PostMapping("/{id}/return")
    public String returnItem(@PathVariable("id") Long id,
                             @RequestParam(value = "redirectTab", required = false) String redirectTab,
                             HttpSession session,
                             RedirectAttributes redirectAttributes) {

        User currentUser = (User) session.getAttribute("currentUser");
        if (currentUser == null) {
            return "redirect:/login";
        }

        try {
            borrowRequestService.returnItem(id, currentUser);
            redirectAttributes.addFlashAttribute("successMessage", "Item successfully returned! It is now AVAILABLE in the campus catalog.");
        } catch (Exception ex) {
            redirectAttributes.addFlashAttribute("errorMessage", ex.getMessage());
        }

        String tab = (redirectTab != null && !redirectTab.isBlank()) ? redirectTab : "incoming";
        return "redirect:/dashboard?tab=" + tab;
    }

    @PostMapping("/{id}/handover")
    public String confirmHandover(@PathVariable("id") Long id,
                                  @RequestParam(value = "redirectTab", required = false) String redirectTab,
                                  HttpSession session,
                                  RedirectAttributes redirectAttributes) {

        User currentUser = (User) session.getAttribute("currentUser");
        if (currentUser == null) {
            return "redirect:/login";
        }

        try {
            borrowRequestService.confirmHandover(id, currentUser);
            redirectAttributes.addFlashAttribute("successMessage",
                "Equipment physically handed over! Status updated to 'Item Issued / Given'.");
        } catch (Exception ex) {
            redirectAttributes.addFlashAttribute("errorMessage", ex.getMessage());
        }

        String tab = (redirectTab != null && !redirectTab.isBlank()) ? redirectTab : "incoming";
        return "redirect:/dashboard?tab=" + tab;
    }

    @PostMapping("/{id}/revert-pickup")
    public String revertPickup(@PathVariable("id") Long id,
                               @RequestParam(value = "redirectTab", required = false) String redirectTab,
                               HttpSession session,
                               RedirectAttributes redirectAttributes) {

        User currentUser = (User) session.getAttribute("currentUser");
        if (currentUser == null) {
            return "redirect:/login";
        }

        try {
            borrowRequestService.revertToAwaitingPickup(id, currentUser);
            redirectAttributes.addFlashAttribute("successMessage",
                "Status updated: Item has not been given yet and remains 'Awaiting Pickup'.");
        } catch (Exception ex) {
            redirectAttributes.addFlashAttribute("errorMessage", ex.getMessage());
        }

        String tab = (redirectTab != null && !redirectTab.isBlank()) ? redirectTab : "incoming";
        return "redirect:/dashboard?tab=" + tab;
    }

    @PostMapping("/{id}/extend")
    public String extendLoan(@PathVariable("id") Long id,
                             @RequestParam("newDueDate") LocalDate newDueDate,
                             @RequestParam(value = "reason", required = false) String reason,
                             HttpSession session,
                             RedirectAttributes redirectAttributes) {

        User currentUser = (User) session.getAttribute("currentUser");
        if (currentUser == null) {
            return "redirect:/login";
        }

        try {
            borrowRequestService.extendLoan(id, newDueDate, reason, currentUser);
            redirectAttributes.addFlashAttribute("successMessage",
                "Loan return deadline extended to " + newDueDate + "! You will receive an automated intimation 1 day prior to your new return date.");
        } catch (Exception ex) {
            redirectAttributes.addFlashAttribute("errorMessage", ex.getMessage());
        }

        return "redirect:/dashboard?tab=outgoing";
    }
}
