package com.campus.lending.controller;

import com.campus.lending.dto.ItemDto;
import com.campus.lending.model.Item;
import com.campus.lending.model.ItemStatus;
import com.campus.lending.model.User;
import com.campus.lending.service.ItemService;
import jakarta.servlet.http.HttpSession;
import jakarta.validation.Valid;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

@Controller
@RequestMapping("/items")
public class ItemManagementController {

    private final ItemService itemService;

    public ItemManagementController(ItemService itemService) {
        this.itemService = itemService;
    }

    @PostMapping("/new")
    public String createItem(@Valid @ModelAttribute("newItemDto") ItemDto itemDto,
                             BindingResult bindingResult,
                             @RequestParam(value = "redirectUrl", required = false) String redirectUrl,
                             HttpSession session,
                             RedirectAttributes redirectAttributes) {

        User currentUser = (User) session.getAttribute("currentUser");
        if (currentUser == null) {
            return "redirect:/login";
        }

        String targetRedirect = (redirectUrl != null && !redirectUrl.trim().isEmpty())
                ? redirectUrl.trim()
                : "/dashboard?tab=items";

        if (bindingResult.hasErrors()) {
            redirectAttributes.addFlashAttribute("errorMessage",
                bindingResult.getAllErrors().get(0).getDefaultMessage());
            return "redirect:" + targetRedirect;
        }

        Item item = new Item(
            currentUser,
            itemDto.getTitle().trim(),
            itemDto.getCategory().trim(),
            itemDto.getDescription() != null ? itemDto.getDescription().trim() : "",
            ItemStatus.AVAILABLE,
            itemDto.getImageUrl() != null ? itemDto.getImageUrl().trim() : ""
        );

        itemService.saveItem(item, currentUser);
        redirectAttributes.addFlashAttribute("successMessage",
            "Item '" + item.getTitle() + "' successfully listed in the campus inventory!");

        return "redirect:" + targetRedirect;
    }

    @PostMapping("/{id}/edit")
    public String updateItem(@PathVariable("id") Long id,
                             @ModelAttribute ItemDto itemDto,
                             HttpSession session,
                             RedirectAttributes redirectAttributes) {

        User currentUser = (User) session.getAttribute("currentUser");
        if (currentUser == null) {
            return "redirect:/login";
        }

        try {
            itemService.updateItem(
                id,
                itemDto.getTitle(),
                itemDto.getCategory(),
                itemDto.getDescription(),
                itemDto.getImageUrl(),
                currentUser
            );
            redirectAttributes.addFlashAttribute("successMessage", "Item updated successfully.");
        } catch (Exception ex) {
            redirectAttributes.addFlashAttribute("errorMessage", ex.getMessage());
        }

        return "redirect:/dashboard?tab=items";
    }

    @PostMapping("/{id}/delete")
    public String deleteItem(@PathVariable("id") Long id,
                             HttpSession session,
                             RedirectAttributes redirectAttributes) {

        User currentUser = (User) session.getAttribute("currentUser");
        if (currentUser == null) {
            return "redirect:/login";
        }

        try {
            itemService.deleteItem(id, currentUser);
            redirectAttributes.addFlashAttribute("successMessage", "Item successfully deleted.");
        } catch (Exception ex) {
            redirectAttributes.addFlashAttribute("errorMessage", ex.getMessage());
        }

        return "redirect:/dashboard?tab=items";
    }
}
