package com.campus.lending.controller;

import com.campus.lending.config.AuthInterceptor;
import com.campus.lending.model.Role;
import com.campus.lending.model.User;
import com.campus.lending.service.UserService;
import jakarta.servlet.http.Cookie;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

@Controller
public class AuthController {

    private final UserService userService;

    public AuthController(UserService userService) {
        this.userService = userService;
    }

    @GetMapping("/login")
    public String showLoginPage(@RequestParam(value = "error", required = false) String error,
                                @RequestParam(value = "logout", required = false) String logout,
                                @RequestParam(value = "redirect", required = false) String redirect,
                                @RequestParam(value = "role", required = false) String requestedRole,
                                HttpSession session,
                                Model model) {
        User currentUser = (User) session.getAttribute("currentUser");
        if (currentUser != null) {
            model.addAttribute("currentUser", currentUser);
        }

        if (error != null) {
            model.addAttribute("errorMessage", error);
        }
        if (logout != null) {
            model.addAttribute("infoMessage", "You have been safely signed out.");
        }
        if (redirect != null) {
            model.addAttribute("redirectUrl", redirect);
        }

        String targetRole = (requestedRole != null && !requestedRole.trim().isEmpty())
            ? requestedRole.trim().toUpperCase()
            : "STUDENT";
        model.addAttribute("selectedRole", targetRole);
        model.addAttribute("roles", Role.values());
        return "auth/login";
    }

    @GetMapping("/login/student")
    public String showStudentLogin() {
        return "redirect:/login?role=STUDENT";
    }

    @GetMapping("/login/lab-incharge")
    public String showLabInchargeLogin() {
        return "redirect:/login?role=LENDER";
    }

    @GetMapping("/login/lender")
    public String showLenderLogin() {
        return "redirect:/login?role=LENDER";
    }

    @GetMapping("/login/approver")
    public String showApproverLogin() {
        return "redirect:/login?role=APPROVER";
    }

    @PostMapping("/login")
    public String handleLogin(@RequestParam("email") String email,
                              @RequestParam(value = "name", required = false) String name,
                              @RequestParam(value = "role", required = false) Role role,
                              @RequestParam(value = "redirect", required = false) String redirect,
                              HttpSession session,
                              HttpServletResponse response,
                              RedirectAttributes redirectAttributes) {

        String validationError = userService.getEmailValidationError(email);
        if (validationError != null) {
            redirectAttributes.addFlashAttribute("errorMessage",
                "Access Denied: You cannot sign in without a proper mail ID. " + validationError);
            redirectAttributes.addFlashAttribute("attemptedEmail", email != null ? email.trim() : "");
            return "redirect:/login" + (role != null ? "?role=" + role.name() : "");
        }

        try {
            User user = userService.authenticateOrRegister(email, name, role != null ? role : Role.STUDENT);
            session.setAttribute("currentUser", user);
            
            // Set 30-day persistent cookie so session never drops across shutdowns
            setRememberCookie(response, user.getEmail());

            redirectAttributes.addFlashAttribute("successMessage",
                "Welcome back, " + user.getName() + "! Signed in as " + user.getRole().getDisplayName() + ".");

            if (redirect != null && !redirect.trim().isEmpty() && !redirect.equals("/login")) {
                return "redirect:" + redirect;
            }
            return "redirect:/catalog";
        } catch (IllegalArgumentException ex) {
            redirectAttributes.addFlashAttribute("errorMessage", ex.getMessage());
            return "redirect:/login" + (role != null ? "?role=" + role.name() : "");
        }
    }

    @GetMapping("/login/demo/{roleName}")
    public String quickDemoLogin(@PathVariable("roleName") String roleName,
                                 HttpSession session,
                                 HttpServletResponse response,
                                 RedirectAttributes redirectAttributes) {
        String email;
        String name;
        Role role;

        switch (roleName.toLowerCase()) {
            case "lab-incharge":
            case "labincharge":
            case "lender":
                email = "alice.labincharge@college.edu";
                name = "Prof. Alice Vance";
                role = Role.LENDER;
                break;
            case "approver":
                email = "miller.approver@college.edu";
                name = "Dr. Robert Miller";
                role = Role.APPROVER;
                break;
            case "admin":
                email = "admin.facility@college.edu";
                name = "Campus Ops Admin";
                role = Role.ADMIN;
                break;
            case "student":
            default:
                email = "bob.student@college.edu";
                name = "Bob Sharma";
                role = Role.STUDENT;
                break;
        }

        User user = userService.authenticateOrRegister(email, name, role);
        session.setAttribute("currentUser", user);
        
        // Set 30-day persistent cookie
        setRememberCookie(response, user.getEmail());

        redirectAttributes.addFlashAttribute("successMessage",
            "Signed in as Demo " + role.getDisplayName() + " (" + user.getName() + ").");
        return "redirect:/catalog";
    }

    @GetMapping("/switch-role")
    public String switchRole(@RequestParam("role") Role role,
                             HttpSession session,
                             RedirectAttributes redirectAttributes) {
        User currentUser = (User) session.getAttribute("currentUser");
        if (currentUser != null && role != null) {
            currentUser.setRole(role);
            userService.save(currentUser);
            session.setAttribute("currentUser", currentUser);
            redirectAttributes.addFlashAttribute("successMessage",
                "Active role switched to: " + role.getDisplayName());
        }
        return "redirect:/dashboard";
    }

    @GetMapping("/logout")
    public String logout(HttpSession session, HttpServletResponse response) {
        removeRememberCookie(response);
        session.invalidate();
        return "redirect:/login?logout=true";
    }

    private void setRememberCookie(HttpServletResponse response, String email) {
        Cookie cookie = new Cookie(AuthInterceptor.REMEMBER_COOKIE_NAME, email);
        cookie.setMaxAge(30 * 24 * 60 * 60); // 30 days
        cookie.setPath("/");
        cookie.setHttpOnly(true);
        response.addCookie(cookie);
    }

    private void removeRememberCookie(HttpServletResponse response) {
        Cookie cookie = new Cookie(AuthInterceptor.REMEMBER_COOKIE_NAME, "");
        cookie.setMaxAge(0);
        cookie.setPath("/");
        cookie.setHttpOnly(true);
        response.addCookie(cookie);
    }
}
