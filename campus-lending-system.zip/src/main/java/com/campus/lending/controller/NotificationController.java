package com.campus.lending.controller;

import com.campus.lending.model.IntimationNotification;
import com.campus.lending.model.User;
import com.campus.lending.repository.IntimationNotificationRepository;
import com.campus.lending.service.ReturnReminderScheduler;
import jakarta.servlet.http.HttpSession;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

@Controller
@RequestMapping("/notifications")
public class NotificationController {

    private final ReturnReminderScheduler returnReminderScheduler;
    private final IntimationNotificationRepository intimationNotificationRepository;

    public NotificationController(ReturnReminderScheduler returnReminderScheduler,
                                  IntimationNotificationRepository intimationNotificationRepository) {
        this.returnReminderScheduler = returnReminderScheduler;
        this.intimationNotificationRepository = intimationNotificationRepository;
    }

    /**
     * Manually triggers the 1-day return date intimation check and email dispatch.
     */
    @PostMapping("/trigger-reminders")
    public String triggerDueReminders(HttpSession session,
                                      @RequestParam(value = "redirectTab", defaultValue = "notifications") String redirectTab,
                                      RedirectAttributes redirectAttributes) {
        User currentUser = (User) session.getAttribute("currentUser");
        if (currentUser == null) {
            return "redirect:/login";
        }

        int sent = returnReminderScheduler.checkAndSendDueReminders();
        if (sent > 0) {
            redirectAttributes.addFlashAttribute("successMessage",
                    "Success! Sent " + sent + " intimation reminder email(s) for items due in 1 day.");
        } else {
            redirectAttributes.addFlashAttribute("infoMessage",
                    "Scan completed. All student borrowers due in 1 day have already received intimation emails.");
        }

        return "redirect:/dashboard?tab=" + redirectTab;
    }

    /**
     * Sends an immediate test 1-day intimation email for a specific active borrow request.
     */
    @PostMapping("/{requestId}/send-now")
    public String sendImmediateIntimation(@PathVariable("requestId") Long requestId,
                                          HttpSession session,
                                          RedirectAttributes redirectAttributes) {
        User currentUser = (User) session.getAttribute("currentUser");
        if (currentUser == null) {
            return "redirect:/login";
        }

        boolean sent = returnReminderScheduler.sendManualIntimation(requestId);
        if (sent) {
            redirectAttributes.addFlashAttribute("successMessage",
                    "Intimation reminder email dispatched immediately to the student borrower!");
        } else {
            redirectAttributes.addFlashAttribute("errorMessage",
                    "Could not send reminder: request is not an active approved/loaned item.");
        }

        return "redirect:/dashboard?tab=incoming";
    }

    /**
     * Returns raw HTML preview of an intimation email.
     */
    @GetMapping(value = "/{id}/preview", produces = MediaType.TEXT_HTML_VALUE)
    @ResponseBody
    public ResponseEntity<String> previewNotification(@PathVariable("id") Long id) {
        return intimationNotificationRepository.findById(id)
                .map(notif -> ResponseEntity.ok(notif.getMessageContent()))
                .orElse(ResponseEntity.notFound().build());
    }
}
