package com.campus.lending.controller;

import com.campus.lending.dto.ItemDto;
import com.campus.lending.model.BorrowRequest;
import com.campus.lending.model.IntimationNotification;
import com.campus.lending.model.Item;
import com.campus.lending.model.User;
import com.campus.lending.service.BorrowRequestService;
import com.campus.lending.service.EmailNotificationService;
import com.campus.lending.service.ItemService;
import jakarta.servlet.http.HttpSession;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;

import java.time.LocalDate;
import java.util.List;

@Controller
public class DashboardController {

    private final BorrowRequestService borrowRequestService;
    private final ItemService itemService;
    private final EmailNotificationService emailNotificationService;

    public DashboardController(BorrowRequestService borrowRequestService,
                               ItemService itemService,
                               EmailNotificationService emailNotificationService) {
        this.borrowRequestService = borrowRequestService;
        this.itemService = itemService;
        this.emailNotificationService = emailNotificationService;
    }

    @GetMapping("/dashboard")
    public String showDashboard(@RequestParam(value = "tab", required = false) String activeTab,
                                HttpSession session,
                                Model model) {

        User currentUser = (User) session.getAttribute("currentUser");
        if (currentUser == null) {
            return "redirect:/login?redirect=/dashboard";
        }

        // 1. My Outgoing Requests (borrower side)
        List<BorrowRequest> myRequests = borrowRequestService.getRequestsByBorrower(currentUser.getId());

        // 2. Incoming Requests to Approve & Issue
        // If Lab Incharge, Approver, or Admin: see all campus equipment requests
        // If Student: requests for items they own
        List<BorrowRequest> incomingRequests;
        if (currentUser.isLabIncharge() || currentUser.isLender() || currentUser.isApprover() || currentUser.isAdmin()) {
            incomingRequests = borrowRequestService.getAllRequests();
        } else {
            incomingRequests = borrowRequestService.getRequestsForLender(currentUser.getId());
        }

        // 3. My Listed Items
        List<Item> myItems = itemService.findByOwner(currentUser.getId());

        // 4. Intimation Notifications & Reminders
        List<IntimationNotification> notifications = (currentUser.isStudent() && !currentUser.isApprover() && !currentUser.isAdmin())
                ? emailNotificationService.getNotificationsForUser(currentUser.getId())
                : emailNotificationService.getAllNotifications();

        // Key metrics
        long outgoingPending = myRequests.stream().filter(BorrowRequest::isPending).count();
        long outgoingApproved = myRequests.stream().filter(BorrowRequest::isActive).count();
        long incomingPending = incomingRequests.stream().filter(BorrowRequest::isPending).count();

        LocalDate tomorrow = LocalDate.now().plusDays(1);
        long loansDueTomorrow = incomingRequests.stream()
                .filter(r -> r.isActive() && tomorrow.equals(r.getDueDate()))
                .count();

        model.addAttribute("myRequests", myRequests);
        model.addAttribute("incomingRequests", incomingRequests);
        model.addAttribute("myItems", myItems);
        model.addAttribute("notifications", notifications);

        model.addAttribute("outgoingPendingCount", outgoingPending);
        model.addAttribute("outgoingApprovedCount", outgoingApproved);
        model.addAttribute("incomingPendingCount", incomingPending);
        model.addAttribute("myItemsCount", myItems.size());
        model.addAttribute("notificationCount", notifications.size());
        model.addAttribute("loansDueTomorrowCount", loansDueTomorrow);

        model.addAttribute("totalCatalogItems", itemService.countTotalItems());
        model.addAttribute("totalBorrowedItems", itemService.countBorrowedItems());

        model.addAttribute("categories", itemService.getAvailableCategories());
        model.addAttribute("newItemDto", new ItemDto());

        // Active tab preference
        String tab = activeTab != null ? activeTab : (currentUser.isLender() || currentUser.isApprover() ? "incoming" : "outgoing");
        model.addAttribute("activeTab", tab);

        return "dashboard/dashboard";
    }
}
