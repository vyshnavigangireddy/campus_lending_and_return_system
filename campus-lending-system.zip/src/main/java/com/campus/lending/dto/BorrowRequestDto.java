package com.campus.lending.dto;

import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;
import org.springframework.format.annotation.DateTimeFormat;

import java.time.LocalDate;

public class BorrowRequestDto {

    private Long itemId;

    @NotNull(message = "Borrow date is required")
    @DateTimeFormat(pattern = "yyyy-MM-dd")
    private LocalDate borrowDate;

    @NotNull(message = "Expected return date is required")
    @DateTimeFormat(pattern = "yyyy-MM-dd")
    private LocalDate dueDate;

    @Size(max = 255, message = "Purpose cannot exceed 255 characters")
    private String purpose;

    public BorrowRequestDto() {
        this.borrowDate = LocalDate.now();
        this.dueDate = LocalDate.now().plusDays(7);
    }

    public BorrowRequestDto(Long itemId, LocalDate borrowDate, LocalDate dueDate, String purpose) {
        this.itemId = itemId;
        this.borrowDate = borrowDate;
        this.dueDate = dueDate;
        this.purpose = purpose;
    }

    public Long getItemId() {
        return itemId;
    }

    public void setItemId(Long itemId) {
        this.itemId = itemId;
    }

    public LocalDate getBorrowDate() {
        return borrowDate;
    }

    public void setBorrowDate(LocalDate borrowDate) {
        this.borrowDate = borrowDate;
    }

    public LocalDate getDueDate() {
        return dueDate;
    }

    public void setDueDate(LocalDate dueDate) {
        this.dueDate = dueDate;
    }

    public String getPurpose() {
        return purpose;
    }

    public void setPurpose(String purpose) {
        this.purpose = purpose;
    }
}
