-- Campus Item Lending & Return System Database Schema
-- Compatible with MySQL 8.x / MariaDB / H2 MySQL-Mode

CREATE TABLE IF NOT EXISTS users (
    id BIGINT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(100) NOT NULL,
    email VARCHAR(150) UNIQUE NOT NULL,
    role VARCHAR(30) DEFAULT 'STUDENT',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS items (
    id BIGINT AUTO_INCREMENT PRIMARY KEY,
    owner_id BIGINT NOT NULL,
    title VARCHAR(120) NOT NULL,
    category VARCHAR(50) NOT NULL,
    description TEXT,
    status VARCHAR(30) DEFAULT 'AVAILABLE',
    image_url VARCHAR(255),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (owner_id) REFERENCES users(id) ON DELETE CASCADE
);

CREATE TABLE IF NOT EXISTS borrow_requests (
    id BIGINT AUTO_INCREMENT PRIMARY KEY,
    item_id BIGINT NOT NULL,
    borrower_id BIGINT NOT NULL,
    status VARCHAR(30) DEFAULT 'PENDING',
    borrow_date DATE NOT NULL,
    due_date DATE NOT NULL,
    purpose VARCHAR(255),
    reminder_sent BOOLEAN DEFAULT FALSE,
    reminder_sent_at TIMESTAMP,
    handover_confirmed_at TIMESTAMP,
    extension_reason VARCHAR(255),
    extended BOOLEAN DEFAULT FALSE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (item_id) REFERENCES items(id) ON DELETE CASCADE,
    FOREIGN KEY (borrower_id) REFERENCES users(id) ON DELETE CASCADE
);

-- Ensure columns exist for existing database files
ALTER TABLE borrow_requests ADD COLUMN IF NOT EXISTS reminder_sent BOOLEAN DEFAULT FALSE;
ALTER TABLE borrow_requests ADD COLUMN IF NOT EXISTS reminder_sent_at TIMESTAMP;
ALTER TABLE borrow_requests ADD COLUMN IF NOT EXISTS handover_confirmed_at TIMESTAMP;
ALTER TABLE borrow_requests ADD COLUMN IF NOT EXISTS extension_reason VARCHAR(255);
ALTER TABLE borrow_requests ADD COLUMN IF NOT EXISTS extended BOOLEAN DEFAULT FALSE;

CREATE TABLE IF NOT EXISTS intimation_notifications (
    id BIGINT AUTO_INCREMENT PRIMARY KEY,
    borrow_request_id BIGINT,
    recipient_id BIGINT NOT NULL,
    recipient_email VARCHAR(150) NOT NULL,
    recipient_name VARCHAR(100) NOT NULL,
    item_title VARCHAR(150) NOT NULL,
    due_date DATE NOT NULL,
    subject VARCHAR(255) NOT NULL,
    message_content TEXT,
    delivery_status VARCHAR(50) DEFAULT 'DELIVERED',
    sent_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (recipient_id) REFERENCES users(id) ON DELETE CASCADE
);
