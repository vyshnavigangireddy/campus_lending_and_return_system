/**
 * Campus Item Lending & Return System - UI Interactions & Modal System
 */

document.addEventListener('DOMContentLoaded', () => {
    initTheme();
    initCatalogSearch();
    initModals();
    initTabs();
    initLoginPortal();
    initEmailValidation();
    initPwaInstall();
});

// Graceful Back / Forward navigation: reset open overlays and scroll lock
window.addEventListener('pageshow', (event) => {
    closeAllModals(false);
    document.body.style.overflow = '';
});

window.addEventListener('popstate', (event) => {
    closeAllModals(false);
    document.body.style.overflow = '';
});

// 1. Theme Management (Light / Dark)
function initTheme() {
    const savedTheme = localStorage.getItem('campus_theme') || 'light';
    document.documentElement.setAttribute('data-theme', savedTheme);

    const themeToggleBtn = document.getElementById('themeToggleBtn');
    if (themeToggleBtn) {
        themeToggleBtn.addEventListener('click', () => {
            const current = document.documentElement.getAttribute('data-theme');
            const next = current === 'dark' ? 'light' : 'dark';
            document.documentElement.setAttribute('data-theme', next);
            localStorage.setItem('campus_theme', next);
        });
    }
}

// 2. Real-time Live Catalog Search & Filter
function initCatalogSearch() {
    const searchInput = document.getElementById('catalogLiveSearch');
    const catalogCards = document.querySelectorAll('.item-card');
    const noResultsEl = document.getElementById('noResultsState');

    if (!searchInput || !catalogCards.length) return;

    searchInput.addEventListener('input', (e) => {
        const query = e.target.value.toLowerCase().trim();
        let visibleCount = 0;

        catalogCards.forEach(card => {
            const title = (card.getAttribute('data-title') || '').toLowerCase();
            const category = (card.getAttribute('data-category') || '').toLowerCase();
            const desc = (card.getAttribute('data-description') || '').toLowerCase();

            if (!query || title.includes(query) || category.includes(query) || desc.includes(query)) {
                card.style.display = 'flex';
                visibleCount++;
            } else {
                card.style.display = 'none';
            }
        });

        if (noResultsEl) {
            noResultsEl.style.display = visibleCount === 0 ? 'block' : 'none';
        }
    });
}

// 3. Modal Controllers
function initModals() {
    // Close modal when clicking overlay background or close button
    document.querySelectorAll('.modal-overlay').forEach(overlay => {
        overlay.addEventListener('click', (e) => {
            if (e.target === overlay || e.target.closest('.modal-close-btn') || e.target.closest('.btn-cancel-modal')) {
                closeAllModals();
            }
        });
    });

    // Close on ESC key
    document.addEventListener('keydown', (e) => {
        if (e.key === 'Escape') {
            closeAllModals();
        }
    });
}

function openModal(modalId) {
    const modal = document.getElementById(modalId);
    if (modal) {
        modal.classList.add('active');
        document.body.style.overflow = 'hidden';
        try {
            history.pushState({ modalOpen: modalId }, '', window.location.href);
        } catch (e) {}
    }
}

function closeAllModals(triggerHistoryBack = true) {
    let wasActive = false;
    document.querySelectorAll('.modal-overlay.active').forEach(modal => {
        modal.classList.remove('active');
        wasActive = true;
    });
    document.body.style.overflow = '';

    if (wasActive && triggerHistoryBack && history.state && history.state.modalOpen) {
        try {
            history.back();
        } catch (e) {}
    }
}

// Helper to open Borrow Modal for a specific item
function openBorrowModal(itemId, title, category, ownerName, imageUrl) {
    const modal = document.getElementById('borrowModal');
    if (!modal) return;

    document.getElementById('borrowItemId').value = itemId;
    document.getElementById('modalItemTitle').textContent = title;
    document.getElementById('modalItemCategory').textContent = category;
    document.getElementById('modalItemOwner').textContent = 'Lab Incharge: ' + ownerName;

    const imgEl = document.getElementById('modalItemImg');
    if (imgEl) {
        imgEl.src = imageUrl || 'https://images.unsplash.com/photo-1581092160607-ee22621dd758?auto=format&fit=crop&w=600&q=80';
    }

    // Set today and +7 days as default dates
    const today = new Date().toISOString().split('T')[0];
    const nextWeek = new Date(Date.now() + 7 * 86400000).toISOString().split('T')[0];

    const startDateInput = document.getElementById('borrowStartDate');
    const returnDateInput = document.getElementById('borrowReturnDate');

    if (startDateInput) {
        startDateInput.value = today;
        startDateInput.min = today;
    }
    if (returnDateInput) {
        returnDateInput.value = nextWeek;
        returnDateInput.min = today;
    }

    openModal('borrowModal');
}

// Helper to open Edit Request Modal
function openEditRequestModal(requestId, borrowDate, dueDate, purpose) {
    const modal = document.getElementById('editRequestModal');
    if (!modal) return;

    const form = document.getElementById('editRequestForm');
    form.action = '/requests/' + requestId + '/edit';

    document.getElementById('editBorrowDate').value = borrowDate;
    document.getElementById('editDueDate').value = dueDate;
    document.getElementById('editPurpose').value = purpose || '';

    openModal('editRequestModal');
}

// Helper to open Cancel Confirmation Modal
function openCancelRequestModal(requestId, itemTitle) {
    const modal = document.getElementById('cancelRequestModal');
    if (!modal) return;

    const form = document.getElementById('cancelRequestForm');
    form.action = '/requests/' + requestId + '/cancel';
    document.getElementById('cancelItemTitle').textContent = itemTitle;

    openModal('cancelRequestModal');
}

// Helper to open Extend Request Modal (Student borrower)
function openExtendModal(requestId, currentDueDate) {
    const modal = document.getElementById('extendRequestModal');
    if (!modal) return;

    const form = document.getElementById('extendRequestForm');
    if (form) form.action = '/requests/' + requestId + '/extend';

    const currentEl = document.getElementById('extendCurrentDueDate');
    if (currentEl) currentEl.textContent = currentDueDate || 'Pending';

    const newDateInput = document.getElementById('extendNewDueDate');
    if (newDateInput) {
        newDateInput.value = '';
        let minDate = currentDueDate;
        if (!minDate) {
            const tmrw = new Date(Date.now() + 86400000);
            minDate = tmrw.toISOString().split('T')[0];
        }
        newDateInput.min = minDate;
    }

    const reasonInput = document.getElementById('extendReason');
    if (reasonInput) reasonInput.value = '';

    openModal('extendRequestModal');
}
window.openExtendModal = openExtendModal;

// Helper to open Return Item Modal
function openReturnItemModal(requestId, itemTitle) {
    const modal = document.getElementById('returnItemModal');
    if (!modal) return;

    const form = document.getElementById('returnItemForm');
    form.action = '/requests/' + requestId + '/return';
    document.getElementById('returnItemTitle').textContent = itemTitle;

    openModal('returnItemModal');
}

// Helper to open Edit Item Modal
function openEditItemModal(itemId, title, category, description, imageUrl) {
    const modal = document.getElementById('editItemModal');
    if (!modal) return;

    const form = document.getElementById('editItemForm');
    form.action = '/items/' + itemId + '/edit';

    document.getElementById('editItemTitleInput').value = title;
    document.getElementById('editItemCategorySelect').value = category;
    document.getElementById('editItemDescInput').value = description || '';
    document.getElementById('editItemImageInput').value = imageUrl || '';

    openModal('editItemModal');
}

// Helper to open Delete Item Modal
function openDeleteItemModal(itemId, title) {
    const modal = document.getElementById('deleteItemModal');
    if (!modal) return;

    const form = document.getElementById('deleteItemForm');
    form.action = '/items/' + itemId + '/delete';
    document.getElementById('deleteItemTitleText').textContent = title;

    openModal('deleteItemModal');
}

// 4. Tab Switcher
function initTabs() {
    const tabBtns = document.querySelectorAll('.tab-btn');
    tabBtns.forEach(btn => {
        btn.addEventListener('click', () => {
            const targetId = btn.getAttribute('data-tab');
            if (!targetId) return;

            tabBtns.forEach(b => b.classList.remove('active'));
            btn.classList.add('active');

            document.querySelectorAll('.tab-pane').forEach(pane => {
                pane.style.display = (pane.id === targetId) ? 'block' : 'none';
            });

            // Update URL hash without jumping
            history.replaceState(null, null, '?tab=' + targetId.replace('-tab', ''));
        });
    });
}

// 5. Role Login Portal Switcher (Student, Lender, Approver)
function initLoginPortal() {
    const roleInput = document.getElementById('roleInput');
    if (!roleInput) return;

    // Check if initial role is set in the hidden input or URL
    const urlParams = new URLSearchParams(window.location.search);
    const roleParam = urlParams.get('role');
    const initialRole = (roleParam || roleInput.value || 'STUDENT').toUpperCase();

    switchLoginRole(initialRole);
}

window.switchLoginRole = function(role) {
    const normalizedRole = (role || 'STUDENT').toUpperCase();
    const roleInput = document.getElementById('roleInput');
    if (roleInput) roleInput.value = normalizedRole;

    // Update active tab buttons
    const tabs = {
        STUDENT: document.getElementById('tabStudent'),
        LENDER: document.getElementById('tabLender'),
        APPROVER: document.getElementById('tabApprover')
    };

    Object.keys(tabs).forEach(r => {
        if (tabs[r]) {
            if (r === normalizedRole) {
                tabs[r].classList.add('active');
            } else {
                tabs[r].classList.remove('active');
            }
        }
    });

    // Elements to dynamically update
    const badgeIcon = document.getElementById('portalBadgeIcon');
    const badgeText = document.getElementById('portalBadgeText');
    const portalTitle = document.getElementById('portalTitle');
    const portalDesc = document.getElementById('portalDesc');
    const emailLabel = document.getElementById('emailLabelRole');
    const emailInput = document.getElementById('emailInput');
    const fastLoginBtn = document.getElementById('fastLoginBtn');
    const fastLoginText = document.getElementById('fastLoginText');
    const fastLoginIcon = document.getElementById('fastLoginIcon');
    const submitBtnText = document.getElementById('submitBtnText');

    if (normalizedRole === 'LENDER') {
        if (badgeIcon) badgeIcon.textContent = '🔬';
        if (badgeText) badgeText.textContent = 'Faculty & Lab Incharge Portal';
        if (portalTitle) portalTitle.textContent = 'Lab Incharge Sign-In';
        if (portalDesc) portalDesc.textContent = 'Sign in as a Lab Incharge to manage lab equipment, confirm physical handovers, and verify gear returns.';
        if (emailLabel) emailLabel.textContent = 'Lab Incharge';
        if (emailInput && !emailInput.value) emailInput.placeholder = 'e.g. alice.labincharge@college.edu';
        if (fastLoginBtn) fastLoginBtn.href = '/login/demo/lab-incharge';
        if (fastLoginIcon) fastLoginIcon.textContent = '🔬';
        if (fastLoginText) fastLoginText.textContent = 'One-Click Lab Incharge Login (Prof. Alice Vance)';
        if (submitBtnText) submitBtnText.textContent = 'Continue to Lab Incharge Portal';
    } else if (normalizedRole === 'APPROVER') {
        if (badgeIcon) badgeIcon.textContent = '🛡️';
        if (badgeText) badgeText.textContent = 'Campus Facility Approver Portal';
        if (portalTitle) portalTitle.textContent = 'Facility Approver Sign-In';
        if (portalDesc) portalDesc.textContent = 'Sign in as facility authority to supervise campus inventory and approve/decline requests across all departments.';
        if (emailLabel) emailLabel.textContent = 'Approver / Admin';
        if (emailInput && !emailInput.value) emailInput.placeholder = 'e.g. miller.approver@college.edu';
        if (fastLoginBtn) fastLoginBtn.href = '/login/demo/approver';
        if (fastLoginIcon) fastLoginIcon.textContent = '🛡️';
        if (fastLoginText) fastLoginText.textContent = 'One-Click Approver Login (Dr. Robert Miller)';
        if (submitBtnText) submitBtnText.textContent = 'Continue to Approver Portal';
    } else {
        // STUDENT default
        if (badgeIcon) badgeIcon.textContent = '🎓';
        if (badgeText) badgeText.textContent = 'Student Borrower Portal';
        if (portalTitle) portalTitle.textContent = 'Student Borrower Sign-In';
        if (portalDesc) portalDesc.textContent = 'Sign in with your campus email to borrow lab equipment, track requests, and return gear.';
        if (emailLabel) emailLabel.textContent = 'Student';
        if (emailInput && !emailInput.value) emailInput.placeholder = 'e.g. bob.student@college.edu';
        if (fastLoginBtn) fastLoginBtn.href = '/login/demo/student';
        if (fastLoginIcon) fastLoginIcon.textContent = '🎓';
        if (fastLoginText) fastLoginText.textContent = 'One-Click Student Login (Bob Sharma)';
        if (submitBtnText) submitBtnText.textContent = 'Continue to Student Portal';
    }
};

// 6. Strict Real-Time Email Validation ("Without proper mail id the user cannot login")
function initEmailValidation() {
    const emailInput = document.getElementById('emailInput');
    const feedbackBox = document.getElementById('emailFeedbackMsg');
    const loginForm = document.getElementById('loginForm');

    if (!emailInput || !feedbackBox || !loginForm) return;

    function validateInput(showEmptyFeedback = false) {
        const val = emailInput.value.trim();
        emailInput.classList.remove('input-shake');

        if (!val) {
            if (showEmptyFeedback) {
                feedbackBox.style.display = 'flex';
                feedbackBox.className = 'email-feedback-box error';
                feedbackBox.innerHTML = '<span>⚠️</span><span>Email address is required. You cannot sign in without a proper mail ID.</span>';
                emailInput.classList.add('input-shake');
            } else {
                feedbackBox.style.display = 'none';
                emailInput.classList.remove('input-valid');
            }
            return false;
        }

        const error = getEmailClientError(val);
        if (error) {
            feedbackBox.style.display = 'flex';
            feedbackBox.className = 'email-feedback-box error';
            feedbackBox.innerHTML = `<span>❌</span><span><strong>Access Denied:</strong> ${error}</span>`;
            emailInput.classList.remove('input-valid');
            return false;
        } else {
            feedbackBox.style.display = 'flex';
            feedbackBox.className = 'email-feedback-box success';
            feedbackBox.innerHTML = '<span>✓</span><span><strong>Proper Mail ID Verified:</strong> Institutional format recognized.</span>';
            emailInput.classList.add('input-valid');
            return true;
        }
    }

    // Live validation as student types
    emailInput.addEventListener('input', () => {
        validateInput(false);
    });

    emailInput.addEventListener('blur', () => {
        validateInput(true);
    });

    // Guard on Form Submit
    loginForm.addEventListener('submit', (e) => {
        const isValid = validateInput(true);
        if (!isValid) {
            e.preventDefault();
            e.stopPropagation();
            emailInput.classList.remove('input-shake');
            void emailInput.offsetWidth; // Trigger reflow to restart animation
            emailInput.classList.add('input-shake');
            emailInput.focus();
            return false;
        }
    });
}

function getEmailClientError(email) {
    if (!email || !email.trim()) {
        return "Email cannot be empty.";
    }
    const trimmed = email.trim();
    if (trimmed.includes(' ')) {
        return "Email cannot contain spaces.";
    }
    if (!trimmed.includes('@')) {
        return "Missing '@' symbol. A proper mail ID requires username@domain.edu.";
    }
    const parts = trimmed.split('@');
    if (parts.length !== 2 || !parts[0] || !parts[1]) {
        return "Improper mail format. Please provide a username and campus domain (e.g., student@college.edu).";
    }
    if (!parts[1].includes('.')) {
        return "Missing domain extension. A proper mail ID must end with .edu, .ac.in, or a valid domain.";
    }
    const domainTokens = parts[1].split('.');
    const tld = domainTokens[domainTokens.length - 1];
    if (tld.length < 2 || !/^[a-zA-Z]+$/.test(tld)) {
        return "Domain extension must be at least 2 letters (e.g., .edu, .org).";
    }
    const rfcPattern = /^[a-zA-Z0-9_+&*-]+(?:\.[a-zA-Z0-9_+&*-]+)*@(?:[a-zA-Z0-9-]+\.)+[a-zA-Z]{2,10}$/;
    if (!rfcPattern.test(trimmed)) {
        return "Improper mail ID format. Please use a proper campus email (e.g., student@college.edu, labincharge@college.edu).";
    }
    return null;
}

// 7. PWA Install Prompt & Offline Support ("Save like an app")
let deferredPrompt = null;
function initPwaInstall() {
    const installBtn = document.getElementById('installAppBtn');
    const modalInstallBtn = document.getElementById('modalPwaInstallBtn');

    window.addEventListener('beforeinstallprompt', (e) => {
        e.preventDefault();
        deferredPrompt = e;
        if (installBtn) {
            installBtn.style.display = 'inline-flex';
        }
    });

    if (installBtn) {
        installBtn.addEventListener('click', () => {
            if (deferredPrompt) {
                triggerNativeInstall();
            } else {
                openModal('installAppModal');
            }
        });
    }

    if (modalInstallBtn) {
        modalInstallBtn.addEventListener('click', () => {
            if (deferredPrompt) {
                triggerNativeInstall();
            } else {
                alert('Browser App Installation:\n\n1. Look at the right side of your browser address bar for the "Install App" (➕ / 🖥️) icon and click it.\n\n2. Or click your browser menu (top right) -> "Apps" -> "Install this site as an app".\n\n3. You can also open "Campus Item Lending App" shortcut directly from your Windows Desktop anytime!');
            }
        });
    }

    async function triggerNativeInstall() {
        if (!deferredPrompt) return;
        deferredPrompt.prompt();
        const { outcome } = await deferredPrompt.userChoice;
        if (outcome === 'accepted') {
            closeAllModals(false);
        }
        deferredPrompt = null;
    }

    // Register service worker if supported
    if ('serviceWorker' in navigator) {
        navigator.serviceWorker.register('/sw.js').catch(err => {
            console.log('SW registration optional:', err);
        });
    }
}

// 8. Image Picker & Live Preview Helpers
window.applyPresetPhoto = function(url, inputId, previewImgId) {
    const input = document.getElementById(inputId);
    if (input) {
        input.value = url;
    }
    updateImagePreview(url, previewImgId);
};

window.updateImagePreview = function(url, previewImgId) {
    const img = document.getElementById(previewImgId);
    if (!img) return;
    const box = img.parentElement;
    if (url && url.trim().length > 0) {
        img.src = url.trim();
        if (box) box.style.display = 'block';
    } else {
        if (box) box.style.display = 'none';
    }
};

window.viewNotificationModal = function(id, subject, recipient, dueDate, itemTitle) {
    const modal = document.getElementById('notificationDetailModal');
    if (!modal) return;
    document.getElementById('notifModalSubject').textContent = subject;
    document.getElementById('notifModalRecipient').textContent = recipient;
    document.getElementById('notifModalItem').textContent = itemTitle;
    document.getElementById('notifModalDueDate').textContent = dueDate;
    
    const iframe = document.getElementById('notifModalFrame');
    if (iframe) {
        iframe.src = '/notifications/' + id + '/preview';
    }
    openModal('notificationDetailModal');
};

