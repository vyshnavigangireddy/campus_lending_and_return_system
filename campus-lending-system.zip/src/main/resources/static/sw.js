// Service Worker for Campus Item Lending & Return System (PWA App Mode)
const CACHE_NAME = 'campus-lending-v2';
const STATIC_ASSETS = [
  '/css/styles.css',
  '/js/app.js',
  '/icons/icon.svg',
  '/manifest.json',
  '/offline.html'
];

self.addEventListener('install', (event) => {
  event.waitUntil(
    caches.open(CACHE_NAME).then((cache) => {
      return cache.addAll(STATIC_ASSETS);
    })
  );
  self.skipWaiting();
});

self.addEventListener('activate', (event) => {
  event.waitUntil(
    caches.keys().then((keys) => {
      return Promise.all(
        keys.filter((key) => key !== CACHE_NAME).map((key) => caches.delete(key))
      );
    })
  );
  self.clients.claim();
});

self.addEventListener('fetch', (event) => {
  // 1. Navigation requests (HTML pages when going back or loading): Network first, fallback to offline.html
  if (event.request.mode === 'navigate') {
    event.respondWith(
      fetch(event.request).catch(() => {
        return caches.match('/offline.html');
      })
    );
    return;
  }

  // 2. Static Assets: Cache first or Network fallback
  if (event.request.method === 'GET' && (
      event.request.url.includes('/css/') ||
      event.request.url.includes('/js/') ||
      event.request.url.includes('/icons/') ||
      event.request.url.includes('fonts.googleapis.com')
  )) {
    event.respondWith(
      caches.match(event.request).then((cachedResponse) => {
        return cachedResponse || fetch(event.request).then((networkResponse) => {
          if (networkResponse && networkResponse.status === 200) {
            const responseClone = networkResponse.clone();
            caches.open(CACHE_NAME).then((cache) => {
              cache.put(event.request, responseClone);
            });
          }
          return networkResponse;
        });
      })
    );
  }
});
