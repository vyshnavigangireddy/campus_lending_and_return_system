-- Sample Seed Data for Campus Item Lending & Return System

-- 1. Insert Sample Users
INSERT INTO users (id, name, email, role) VALUES
(1, 'Prof. Alice Vance', 'alice.lender@college.edu', 'LENDER'),
(2, 'Dr. Robert Miller', 'miller.approver@college.edu', 'APPROVER'),
(3, 'Bob Sharma', 'bob.student@college.edu', 'STUDENT'),
(4, 'Elena Rostova', 'elena.student@college.edu', 'STUDENT'),
(5, 'Campus Ops Admin', 'admin.facility@college.edu', 'ADMIN');

-- 2. Insert Sample Items
INSERT INTO items (id, owner_id, title, category, description, status, image_url) VALUES
(1, 1, 'Digital Storage Oscilloscope 100MHz (Rigol DS1054Z)', 'Electronics', '4-channel 100MHz digital storage oscilloscope with 24Mpts memory depth and 4 passive probes.', 'AVAILABLE', 'https://images.unsplash.com/photo-1581092160607-ee22621dd758?auto=format&fit=crop&w=600&q=80'),
(2, 1, 'Texas Instruments TI-84 Plus CE Graphing Calculator', 'Electronics', 'High-resolution backlit color screen graphing calculator with rechargeable battery.', 'BORROWED', 'https://images.unsplash.com/photo-1594980596870-8aa52a78d8cd?auto=format&fit=crop&w=600&q=80'),
(3, 1, 'Raspberry Pi 5 (8GB RAM) Embedded Kit', 'Electronics', 'Broadcom BCM2712 quad-core Cortex-A76, active cooler, official power supply, and 64GB microSD.', 'AVAILABLE', 'https://images.unsplash.com/photo-1629654297299-c8506221ca97?auto=format&fit=crop&w=600&q=80'),
(4, 2, 'Advanced Organic Chemistry Glassware Kit (24/40)', 'Lab Kits', 'Heavy-duty borosilicate glassware set including round bottom flasks and distillation adapter.', 'AVAILABLE', 'https://images.unsplash.com/photo-1582719508461-905c673771fd?auto=format&fit=crop&w=600&q=80'),
(5, 2, 'Vernier LabQuest 2 Multi-Sensor Station', 'Lab Kits', 'Standalone laboratory data logger with optical dissolved oxygen probe and pH electrode.', 'AVAILABLE', 'https://images.unsplash.com/photo-1532187863486-abf9dbad1b69?auto=format&fit=crop&w=600&q=80'),
(6, 1, 'TurtleBot3 Burger Mobile Robot (ROS2)', 'Robotics & IoT', 'Compact mobile robot equipped with 360-degree LiDAR and OpenCR controller.', 'AVAILABLE', 'https://images.unsplash.com/photo-1485827404703-89b55fcc595e?auto=format&fit=crop&w=600&q=80'),
(7, 3, 'Introduction to Algorithms (CLRS 4th Edition)', 'Books & Courseware', 'Textbook covering algorithm analysis, graph theory, and dynamic programming.', 'AVAILABLE', 'https://images.unsplash.com/photo-1544716278-ca5e3f4abd8c?auto=format&fit=crop&w=600&q=80'),
(8, 5, 'Sony Alpha a6400 4K Mirrorless Camera + Tripod', 'Audio & Visual', 'Mirrorless camera with real-time Eye AF, 4K recording, and lightweight Manfrotto tripod.', 'AVAILABLE', 'https://images.unsplash.com/photo-1516035069371-29a1b244cc32?auto=format&fit=crop&w=600&q=80'),
(9, 5, 'Wilson NCAA Official Game Basketball & Dual Pump', 'Sports Gear', 'Composite leather official size 7 basketball with dual-action hand pump.', 'BORROWED', 'https://images.unsplash.com/photo-1519861531473-9200262188bf?auto=format&fit=crop&w=600&q=80'),
(10, 1, 'DJI Mini 4 Pro 4K Drone Aerial Surveying Kit', 'Robotics & IoT', 'Foldable drone with 4K HDR vertical shooting and omnidirectional sensing.', 'AVAILABLE', 'https://images.unsplash.com/photo-1527977966376-1c8408f9f108?auto=format&fit=crop&w=600&q=80'),
(11, 1, 'Creality Ender-3 V3 High-Speed 3D Printer (250mm/s)', 'Electronics', 'CoreXZ 3D printer with direct drive extruder and automatic bed leveling.', 'AVAILABLE', 'https://images.unsplash.com/photo-1615996001375-c7ef13294436?auto=format&fit=crop&w=600&q=80'),
(12, 5, 'Bose QuietComfort 45 Active Noise-Cancelling Headphones', 'Audio & Visual', 'Acoustic noise cancelling headphones with TriPort architecture.', 'AVAILABLE', 'https://images.unsplash.com/photo-1505740420928-5e560c06d30e?auto=format&fit=crop&w=600&q=80'),
(13, 2, 'Olympus CX23 Binocular LED Biological Microscope', 'Lab Kits', 'Ergonomic compound student microscope with plan achromat objectives.', 'AVAILABLE', 'https://images.unsplash.com/photo-1516321318423-f06f85e504b3?auto=format&fit=crop&w=600&q=80'),
(14, 2, 'Fluke 87V Industrial True-RMS Digital Multimeter', 'Electronics', 'Accurate electrical voltage and frequency measurements. CAT IV certified.', 'AVAILABLE', 'https://images.unsplash.com/photo-1581092335397-9583fe92d232?auto=format&fit=crop&w=600&q=80');

-- 3. Insert Sample Borrow Requests
INSERT INTO borrow_requests (id, item_id, borrower_id, status, borrow_date, due_date, purpose, reminder_sent) VALUES
(1, 1, 3, 'PENDING', CURRENT_DATE, DATEADD('DAY', 5, CURRENT_DATE), 'ECE 410 Senior Design: Inverter noise ripple calibration.', FALSE),
(2, 2, 3, 'APPROVED', DATEADD('DAY', -5, CURRENT_DATE), DATEADD('DAY', 1, CURRENT_DATE), 'Multivariable Calculus Midterm Examination preparation.', FALSE),
(3, 9, 4, 'APPROVED', DATEADD('DAY', -1, CURRENT_DATE), DATEADD('DAY', 2, CURRENT_DATE), 'Inter-dorm weekend basketball tournament practice.', FALSE);
