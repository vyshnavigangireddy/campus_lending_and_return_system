package com.campus.lending;

import com.campus.lending.model.*;
import com.campus.lending.service.BorrowRequestService;
import com.campus.lending.service.ItemService;
import com.campus.lending.service.UserService;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.web.servlet.MockMvc;

import java.time.LocalDate;

import static org.junit.jupiter.api.Assertions.*;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

@SpringBootTest
@AutoConfigureMockMvc
class CampusLendingApplicationTests {

    @Autowired
    private MockMvc mockMvc;

    @Autowired
    private UserService userService;

    @Autowired
    private ItemService itemService;

    @Autowired
    private BorrowRequestService borrowRequestService;

    @Test
    @DisplayName("Context loads and seeded data is present")
    void contextLoads() {
        assertNotNull(userService);
        assertNotNull(itemService);
        assertNotNull(borrowRequestService);
        assertTrue(itemService.getAllItems().size() >= 5);
    }

    @Test
    @DisplayName("Email validation: Reject invalid emails and accept proper campus emails")
    void testEmailValidation() {
        // Valid emails
        assertTrue(userService.isValidEmail("student@college.edu"));
        assertTrue(userService.isValidEmail("john.doe@university.ac.in"));
        assertTrue(userService.isValidEmail("faculty@campus.edu"));

        // Invalid emails
        assertFalse(userService.isValidEmail(""));
        assertFalse(userService.isValidEmail("not-an-email"));
        assertFalse(userService.isValidEmail("student@"));
        assertFalse(userService.isValidEmail("@college.edu"));
        assertFalse(userService.isValidEmail("student@college"));
    }

    @Test
    @DisplayName("Login rejects improper email with error message")
    void testLoginRejectionForInvalidEmail() throws Exception {
        mockMvc.perform(post("/login")
                .param("email", "invalid_email_without_domain"))
                .andExpect(status().is3xxRedirection())
                .andExpect(redirectedUrl("/login"))
                .andExpect(flash().attributeExists("errorMessage"));
    }

    @Test
    @DisplayName("Lab Incharge, Approver, and Student demo logins succeed")
    void testDemoLogins() throws Exception {
        // Test Lab Incharge login
        mockMvc.perform(get("/login/demo/lab-incharge"))
                .andExpect(status().is3xxRedirection())
                .andExpect(redirectedUrl("/catalog"))
                .andExpect(flash().attributeExists("successMessage"));

        // Test Lender legacy route
        mockMvc.perform(get("/login/demo/lender"))
                .andExpect(status().is3xxRedirection())
                .andExpect(redirectedUrl("/catalog"))
                .andExpect(flash().attributeExists("successMessage"));

        // Test Approver login
        mockMvc.perform(get("/login/demo/approver"))
                .andExpect(status().is3xxRedirection())
                .andExpect(redirectedUrl("/catalog"))
                .andExpect(flash().attributeExists("successMessage"));
    }

    @Test
    @DisplayName("Complete Lifecycle: Request -> Approve(Not Given) -> Handover(Loaned) -> Student Extend -> Lab Incharge Return")
    void testBorrowRequestLifecycle() {
        // 1. Create a Lab Incharge (equipment owner) and student
        User labIncharge = userService.authenticateOrRegister("prof.labincharge@college.edu", "Prof. Vance", Role.LENDER);
        User student = userService.authenticateOrRegister("student.tester@college.edu", "Student Tester", Role.STUDENT);

        // 2. Create an available item owned by Lab Incharge
        Item item = itemService.saveItem(new Item(
                labIncharge, "Spectrum Analyzer", "Electronics", "High frequency testing", ItemStatus.AVAILABLE, ""
        ), labIncharge);

        assertEquals(ItemStatus.AVAILABLE, item.getStatus());

        // 3. Student requests to borrow item
        BorrowRequest request = borrowRequestService.createRequest(
                item.getId(),
                student,
                LocalDate.now(),
                LocalDate.now().plusDays(3),
                "Signal distortion lab experiment"
        );

        assertNotNull(request.getId());
        assertEquals(RequestStatus.PENDING, request.getStatus());

        // 4. Lab Incharge / Approver approves the request -> APPROVED ("Awaiting Pickup")
        BorrowRequest approved = borrowRequestService.approveRequest(request.getId(), labIncharge);
        assertEquals(RequestStatus.APPROVED, approved.getStatus());
        assertEquals("Awaiting Pickup", approved.getStatus().getDisplayName());
        assertTrue(approved.isAwaitingHandover());
        assertTrue(approved.isAwaitingPickup());

        // 5. Lab Incharge confirms physical handover -> LOANED ("Item Issued / Given")
        BorrowRequest loaned = borrowRequestService.confirmHandover(approved.getId(), labIncharge);
        assertEquals(RequestStatus.LOANED, loaned.getStatus());
        assertEquals("Item Issued / Given", loaned.getStatus().getDisplayName());
        assertTrue(loaned.isLoaned());
        assertTrue(loaned.isItemGiven());
        assertTrue(loaned.isItemIssued());
        assertNotNull(loaned.getHandoverConfirmedAt());

        // Test reverting: if item was not given after all -> back to Awaiting Pickup
        BorrowRequest reverted = borrowRequestService.revertToAwaitingPickup(loaned.getId(), labIncharge);
        assertEquals(RequestStatus.APPROVED, reverted.getStatus());
        assertEquals("Awaiting Pickup", reverted.getStatus().getDisplayName());

        // Re-issue to student
        loaned = borrowRequestService.confirmHandover(reverted.getId(), labIncharge);
        assertEquals(RequestStatus.LOANED, loaned.getStatus());

        // Verify item is now marked as BORROWED
        Item updatedItem = itemService.findById(item.getId()).orElseThrow();
        assertEquals(ItemStatus.BORROWED, updatedItem.getStatus());

        // 6. Student needs more time -> Student extends loan return date
        LocalDate extendedDate = LocalDate.now().plusDays(7);
        BorrowRequest extended = borrowRequestService.extendLoan(
                loaned.getId(), extendedDate, "Extra verification testing needed for final report", student
        );
        assertEquals(extendedDate, extended.getDueDate());
        assertTrue(extended.isExtended());
        assertEquals("Extra verification testing needed for final report", extended.getExtensionReason());

        // 7. Security: Student MUST NOT be allowed to confirm return (Only Lab Incharge has return access!)
        assertThrows(SecurityException.class, () -> {
            borrowRequestService.returnItem(extended.getId(), student);
        }, "Students must be rejected if attempting to confirm return directly");

        // 8. Lab Incharge confirms physical gear returned
        BorrowRequest returned = borrowRequestService.returnItem(extended.getId(), labIncharge);
        assertEquals(RequestStatus.RETURNED, returned.getStatus());

        // Verify item is now restored to AVAILABLE
        Item finalItem = itemService.findById(item.getId()).orElseThrow();
        assertEquals(ItemStatus.AVAILABLE, finalItem.getStatus());
    }

    @Test
    @DisplayName("Catalog endpoint renders HTML successfully")
    void testCatalogPage() throws Exception {
        mockMvc.perform(get("/catalog"))
                .andExpect(status().isOk())
                .andExpect(view().name("catalog/catalog"))
                .andExpect(model().attributeExists("items"))
                .andExpect(model().attributeExists("categories"));
    }

    @Test
    @DisplayName("Direct role login routes redirect properly")
    void testDirectRoleLoginRoutes() throws Exception {
        mockMvc.perform(get("/login/lab-incharge"))
                .andExpect(status().is3xxRedirection())
                .andExpect(redirectedUrl("/login?role=LENDER"));

        mockMvc.perform(get("/login/lender"))
                .andExpect(status().is3xxRedirection())
                .andExpect(redirectedUrl("/login?role=LENDER"));

        mockMvc.perform(get("/login/approver"))
                .andExpect(status().is3xxRedirection())
                .andExpect(redirectedUrl("/login?role=APPROVER"));

        mockMvc.perform(get("/login/student"))
                .andExpect(status().is3xxRedirection())
                .andExpect(redirectedUrl("/login?role=STUDENT"));
    }

    @Test
    @DisplayName("Comprehensive email rejection tests: User cannot login without proper mail ID")
    void testComprehensiveEmailRejection() throws Exception {
        String[] invalidEmails = {
            "",
            "   ",
            "notanemail",
            "student@",
            "@college.edu",
            "student@college",
            "student@.edu",
            "student@college..edu",
            "student with spaces@college.edu"
        };

        for (String invalidEmail : invalidEmails) {
            assertFalse(userService.isValidEmail(invalidEmail), "Should be invalid: " + invalidEmail);
            assertNotNull(userService.getEmailValidationError(invalidEmail), "Should provide validation error: " + invalidEmail);

            mockMvc.perform(post("/login").param("email", invalidEmail))
                    .andExpect(status().is3xxRedirection())
                    .andExpect(flash().attributeExists("errorMessage"));
        }
    }

    @Autowired
    private com.campus.lending.service.ReturnReminderScheduler returnReminderScheduler;

    @Autowired
    private com.campus.lending.repository.IntimationNotificationRepository intimationNotificationRepository;

    @Test
    @DisplayName("Lender has access to add items in the website")
    void testLenderCanAddItem() {
        User lender = userService.authenticateOrRegister("lender.newitem@college.edu", "Prof. Items", Role.LENDER);

        Item newItem = new Item(
                lender,
                "Microchip PIC18F Development Board",
                "Electronics",
                "Advanced 8-bit MCU board with onboard debugger",
                ItemStatus.AVAILABLE,
                "https://images.unsplash.com/photo-1581092160607-ee22621dd758"
        );

        Item saved = itemService.saveItem(newItem, lender);
        assertNotNull(saved.getId());
        assertEquals("Microchip PIC18F Development Board", saved.getTitle());
        assertEquals(lender.getId(), saved.getOwner().getId());
        assertEquals(ItemStatus.AVAILABLE, saved.getStatus());

        // Verify it is retrieved in catalog
        assertTrue(itemService.getAllItems().stream().anyMatch(i -> i.getId().equals(saved.getId())));
    }

    @Test
    @DisplayName("Student gets intimation mail before 1 day of return date")
    void testStudentGetsIntimationMailBeforeOneDayOfReturn() {
        // 1. Create lender and student
        User lender = userService.authenticateOrRegister("prof.reminder@college.edu", "Prof. Reminder", Role.LENDER);
        User student = userService.authenticateOrRegister("student.reminder@college.edu", "Student Reminder", Role.STUDENT);

        // 2. Create item and active borrow request due TOMORROW (1 day before return date)
        Item item = itemService.saveItem(new Item(
                lender, "Precision Digital Caliper 150mm", "Mechanical Tools", "Stainless steel measurement caliper",
                ItemStatus.AVAILABLE, ""
        ), lender);

        LocalDate borrowDate = LocalDate.now().minusDays(6);
        LocalDate dueDateTomorrow = LocalDate.now().plusDays(1); // Exactly 1 day before return date

        BorrowRequest request = borrowRequestService.createRequest(
                item.getId(),
                student,
                borrowDate,
                dueDateTomorrow,
                "Mechanical workshop prototype tolerance check"
        );

        BorrowRequest approved = borrowRequestService.approveRequest(request.getId(), lender);
        assertFalse(approved.isReminderSent(), "Reminder should not be marked sent initially");

        // 3. Trigger 1-day intimation scan
        int intimationsSent = returnReminderScheduler.checkAndSendDueReminders();
        assertTrue(intimationsSent >= 1, "Should have dispatched at least 1 intimation reminder");

        // 4. Verify intimation record in database
        var notifications = intimationNotificationRepository.findByRecipientIdOrderBySentAtDesc(student.getId());
        assertFalse(notifications.isEmpty(), "Student should have received an intimation record");

        var latestNotif = notifications.get(0);
        assertEquals(student.getEmail(), latestNotif.getRecipientEmail());
        assertEquals("Precision Digital Caliper 150mm", latestNotif.getItemTitle());
        assertTrue(latestNotif.getSubject().contains("Return Reminder"));
        assertTrue(latestNotif.getMessageContent().contains("1-Day Return Intimation Notice"));
        assertTrue(latestNotif.getMessageContent().contains("Precision Digital Caliper 150mm"));

        // 5. Verify request marked as reminder sent
        BorrowRequest reloaded = borrowRequestService.getRequestsByBorrower(student.getId()).stream()
                .filter(r -> r.getId().equals(approved.getId()))
                .findFirst().orElseThrow();
        assertTrue(reloaded.isReminderSent());
        assertNotNull(reloaded.getReminderSentAt());
    }

    @Test
    @DisplayName("User can request to borrow their own listed item without restriction")
    void testUserCanRequestOwnListedItem() {
        User incharge = userService.authenticateOrRegister("incharge.self@college.edu", "Prof. Self", Role.LENDER);
        Item item = itemService.saveItem(new Item(
                incharge, "Fluke Digital Multimeter 87V", "Electronics", "Industrial multimeter", ItemStatus.AVAILABLE, ""
        ), incharge);

        // Lab incharge / owner requests to borrow their own listed item
        BorrowRequest req = borrowRequestService.createRequest(
                item.getId(),
                incharge,
                LocalDate.now(),
                LocalDate.now().plusDays(5),
                "Internal lab testing and sensor calibration"
        );

        assertNotNull(req.getId());
        assertEquals(RequestStatus.PENDING, req.getStatus());
        assertEquals(incharge.getId(), req.getBorrower().getId());
        assertEquals(incharge.getId(), req.getItem().getOwner().getId());

        // Approve -> Awaiting Pickup
        BorrowRequest approved = borrowRequestService.approveRequest(req.getId(), incharge);
        assertEquals(RequestStatus.APPROVED, approved.getStatus());
        assertEquals("Awaiting Pickup", approved.getStatus().getDisplayName());

        // Confirm handover -> Item Issued / Given
        BorrowRequest handedOver = borrowRequestService.confirmHandover(approved.getId(), incharge);
        assertEquals(RequestStatus.LOANED, handedOver.getStatus());
        assertEquals("Item Issued / Given", handedOver.getStatus().getDisplayName());

        // Confirm return -> Returned
        BorrowRequest returned = borrowRequestService.returnItem(handedOver.getId(), incharge);
        assertEquals(RequestStatus.RETURNED, returned.getStatus());
        assertEquals("Returned", returned.getStatus().getDisplayName());
    }
}
