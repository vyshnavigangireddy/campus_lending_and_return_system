# Theoretical Foundations & Architectural Analysis of the Campus Item Lending & Return System

## Academic Classification
**Department of Computer Science & Software Engineering**  
*A Formal Theoretical Treatise on Collaborative Resource Sharing, Finite State Automata, Relational Normalization, and Human-Computer Interaction*

---

## Abstract
Higher educational institutions house specialized laboratory and athletic assets that suffer from sub-optimal utilization, departmental silos, and high rates of equipment misplacement. This paper investigates the theoretical, mathematical, architectural, and cognitive foundations underlying the design and implementation of the **Campus Item Lending & Return System**. We model item borrowing as a multi-agent discrete state machine, analyze relational schema normalization against Codd's Normal Forms, formalize role-based access control (RBAC) lattices, evaluate cognitive load under Miller's and Hick's Laws, and demonstrate fault tolerance through non-volatile relational storage and cookie-backed session reconciliation.

---

## 1. Introduction & Theoretical Background

### 1.1 The Theory of Collaborative Resource Sharing (Club Goods)
In microeconomic theory and institutional economics, specialized university lab hardware—such as digital storage oscilloscopes, optical sensors, GPU accelerator boards, and surveying gear—constitutes a class of capital known as **Club Goods** or **Common-Pool Resources** (*Ostrom, 1990*). These assets exhibit:
1. **High Initial Capital Expenditure (CapEx)**: Prohibitive for individual student purchase.
2. **Intermittent Temporal Demand**: Intensive utilization during project evaluation windows; low utilization otherwise.
3. **Excludability & Non-Rivalry within the Club**: Access is restricted to authenticated institutional members without consumption rivalry under proper scheduling.

The foundational theory of **Collaborative Consumption** (*Botsman & Rogers, 2010*) demonstrates that asset efficiency is maximized when asset idle capacity is redistributed through frictionless discovery mechanisms. In traditional university environments, asset allocation fails due to severe **information asymmetry**, lack of search liquidity, and zero trust verification.

### 1.2 Historical Evolution of Campus Asset Tracking
- **Phase I (1950–1990) — Physical Register Paradigm**: Pen-and-paper sign-out logbooks. Vulnerable to physical destruction, illegible handwriting, absence of due-date enforcement, and complete departmental isolation.
- **Phase II (2000–2015) — Ad-Hoc Spreadsheet Paradigm**: Local Excel workbooks and WhatsApp messaging. Lacked concurrent multi-user synchronization, created race conditions, and lacked automated access control.
- **Phase III (Present) — Enterprise Integrated Lifecycle Governance**: Centralized web architecture governed by deterministic finite state automata, relational ACID durability, and role-based permissions.

---

## 2. Formal Problem Formulation & Mathematical Modeling

### 2.1 Discrete System Model
The Campus Item Lending System is formally defined as a 6-tuple:

$$\mathcal{S} = \langle \mathcal{U}, \mathcal{I}, \mathcal{C}, \mathcal{R}, \mathcal{T}, \Delta \rangle$$

Where:
- $\mathcal{U} = \{ u_1, u_2, \dots, u_n \}$ represents the universe of verified institutional users, where $u = \langle id, name, email, role \rangle$.
- $\mathcal{I} = \{ i_1, i_2, \dots, i_m \}$ denotes physical inventory items, where $i = \langle id, owner\_id, title, category, status \rangle$, with $status \in \{ \text{AVAILABLE}, \text{BORROWED} \}$.
- $\mathcal{C} = \{ \text{Electronics}, \text{Lab Kits}, \text{Books}, \text{Sports Gear}, \text{Audio/Visual}, \text{Robotics} \}$ represents discrete academic categories.
- $\mathcal{R} = \{ r_1, r_2, \dots, r_k \}$ represents borrow requests, where $r = \langle id, item\_id, borrower\_id, borrow\_date, due\_date, status \rangle$.
- $\mathcal{T}$ represents discrete calendar time intervals ($t_{borrow} \le t_{due}$).
- $\Delta$ represents the state transition function.

### 2.2 Systemic Invariants & Constraint Proofs
To guarantee mathematical consistency, the system enforces three core invariants:

$$\textbf{Invariant 1 (Asset Mutual Exclusion): } \forall i \in \mathcal{I}, \forall t \in \mathcal{T}, \quad |\{ r \in \mathcal{R} \mid r.item = i \land r.status = \text{APPROVED} \}| \le 1$$

$$\textbf{Invariant 2 (Identity Non-Reflexivity): } \forall r \in \mathcal{R}, \quad r.borrower\_id \ne r.item.owner\_id$$

$$\textbf{Invariant 3 (Temporal Monotonicity): } \forall r \in \mathcal{R}, \quad r.due\_date \ge r.borrow\_date \ge t_{current}$$

---

## 3. Software Engineering Theory & Architectural Patterns

### 3.1 Model-View-Controller (MVC) Pattern
The application architecture adheres to the classical **Model-View-Controller** pattern (*Gamma et al., 1994*), enforcing strict Separation of Concerns:
- **Model**: Encapsulates data integrity and entity relations (`User`, `Item`, `BorrowRequest`). Pure domain objects remain decoupled from presentation and network protocols.
- **View**: Semantic HTML5 templates rendered server-side via Thymeleaf. Eliminates client-side hydration delays, ensures immediate search indexing, and renders clean HTML with zero layout shifts.
- **Controller**: Manages HTTP verb mapping, validates incoming parameters against regular grammars, coordinates business service execution, and returns the appropriate view model.

### 3.2 Layered Enterprise Architecture
```
┌────────────────────────────────────────────────────────┐
│   Presentation Layer (Controllers & View Templates)    │
│   AuthController, CatalogController, DashboardCtrl     │
└───────────────────────────┬────────────────────────────┘
                            │
┌───────────────────────────▼────────────────────────────┐
│   Business Domain / Service Layer                      │
│   UserService, ItemService, BorrowRequestService       │
│   (Transaction Boundaries @Transactional, RBAC Rules)  │
└───────────────────────────┬────────────────────────────┘
                            │
┌───────────────────────────▼────────────────────────────┐
│   Data Access / Repository Layer (Spring Data JPA)     │
│   UserRepository, ItemRepository, BorrowRequestRepo    │
└───────────────────────────┬────────────────────────────┘
                            │
┌───────────────────────────▼────────────────────────────┐
│   Persistence Layer (Hibernate ORM & Disk Database)    │
│   Non-Volatile Relational Storage (./data/...)         │
└────────────────────────────────────────────────────────┘
```

---

## 4. Database Theory & Relational Normalization

### 4.1 Normal Form Evaluation (1NF to 3NF)
- **First Normal Form (1NF)**: All attributes contain strictly atomic, indivisible values. Tables possess distinct surrogate primary keys (`id BIGINT AUTO_INCREMENT`).
- **Second Normal Form (2NF)**: Meets 1NF, and all non-key attributes are fully functionally dependent on the primary key, eliminating partial dependencies.
- **Third Normal Form (3NF)**: Meets 2NF and contains no transitive functional dependencies ($X \rightarrow Y \rightarrow Z$). Foreign keys (`owner_id`, `borrower_id`, `item_id`) establish relational links without duplicating mutable entity fields.

### 4.2 ACID Guarantees
- **Atomicity**: The double-mutation occurring during request approval (updating `BorrowRequest` to `APPROVED` and `Item` to `BORROWED`) is executed inside a single `@Transactional` boundary. Partial state modifications are automatically rolled back.
- **Consistency**: Guaranteed through database foreign key constraints (`ON DELETE CASCADE`), unique constraints (`UNIQUE(email)`), and entity-level validators.
- **Isolation**: Handled under `READ_COMMITTED` isolation, preventing dirty reads during concurrent borrow requests.
- **Durability**: Guaranteed via Write-Ahead Logging (WAL) into persistent non-volatile disk storage (`./data/campus_lending_db.mv.db`).

---

## 5. Access Control & Security Theory

### 5.1 Role-Based Access Control (RBAC) Lattice
Access governance is modeled via a formal RBAC hierarchy:

$$\text{STUDENT} \subset \text{LENDER} \subset \text{APPROVER} \subset \text{ADMIN}$$

| Role | Operational Scope | Authorized Permissions |
| :--- | :--- | :--- |
| **STUDENT** | Individual | Browse catalog, submit requests, edit/cancel owned pending requests, return borrowed items. |
| **LENDER** | Department Assets | All student rights + list department items, edit owned items, approve/decline owned requests, confirm returns. |
| **APPROVER** | Campus-Wide | All lender rights + view all campus requests, approve/decline any departmental loan, view institutional metrics. |
| **ADMIN** | System-Wide | Universal access, user role modifications, system audit trails. |

### 5.2 Formal Grammar for Email Validation
Authentication input is verified using a Chomsky Type-3 Regular Grammar:

$$\mathcal{L}(G) = \{ w \in \Sigma^* \mid w \text{ matches } \text{\texttt{^[a-zA-Z0-9.\_%+-]+@[a-zA-Z0-9.-]+\\.[a-zA-Z]{2,}\$ }} \}$$

Any input string $w \notin \mathcal{L}(G)$ is rejected at the controller gate, preventing unauthorized or malformed entries from reaching the session state.

---

## 6. Finite State Automata (FSA) of Request Lifecycles

The lifecycle of each request is governed by a Deterministic Finite State Automaton:

$$M = (Q, \Sigma, \delta, q_0, F)$$

Where:
- $Q = \{ \text{START}, \text{PENDING}, \text{APPROVED}, \text{REJECTED}, \text{RETURNED}, \text{CANCELLED} \}$
- $\Sigma = \{ \text{submit\_req}, \text{edit\_req}, \text{cancel\_req}, \text{approve\_req}, \text{decline\_req}, \text{return\_item} \}$
- $q_0 = \text{START}$
- $F = \{ \text{RETURNED}, \text{REJECTED}, \text{CANCELLED} \}$

### State Transition Matrix:
$$\delta(\text{START}, \text{submit\_req}) \rightarrow \text{PENDING} \quad (\text{Item: AVAILABLE})$$
$$\delta(\text{PENDING}, \text{edit\_req}) \rightarrow \text{PENDING} \quad (\text{Item: AVAILABLE})$$
$$\delta(\text{PENDING}, \text{cancel\_req}) \rightarrow \text{CANCELLED} \quad (\text{Item: AVAILABLE})$$
$$\delta(\text{PENDING}, \text{approve\_req}) \rightarrow \text{APPROVED} \quad (\text{Item: BORROWED})$$
$$\delta(\text{PENDING}, \text{decline\_req}) \rightarrow \text{REJECTED} \quad (\text{Item: AVAILABLE})$$
$$\delta(\text{APPROVED}, \text{return\_item}) \rightarrow \text{RETURNED} \quad (\text{Item: AVAILABLE})$$

---

## 7. Human-Computer Interaction (HCI) & Cognitive Theory

### 7.1 Cognitive Laws Applied
- **Miller's Law (Chunking)**: Short-term memory holds $7 \pm 2$ items. Item cards visually chunk data into four distinct sections: (1) Image preview with category tag, (2) Title & description, (3) Owner avatar badge, (4) Call-to-action button with status pill.
- **Hick's Law (Decision Latency)**: Decision time scales logarithmically: $T = b \log_2(n + 1)$. Rather than exposing confusing configuration menus, single-click modal dialogs are prefilled with sensible defaults (start date = today, due date = today + 7 days).
- **Fitts's Law (Target Acquisition)**: High-importance targets (e.g., "Request to Borrow", "Approve", "Return") possess generous hit-box dimensions and high visual contrast.

### 7.2 Optical Depth & Spatial Glassmorphism
The interface utilizes multi-layered glassmorphic depth (`backdrop-filter: blur(16px)`). By rendering background campus photography beneath semi-transparent frosted surfaces, the user retains a sense of physical campus context while maintaining high visual contrast on active foreground elements.

---

## 8. Fault Tolerance, Persistence & Resilience Theory

1. **Non-Volatile Relational Storage**:
   Replaces volatile RAM buffers (`jdbc:h2:mem:...`) with non-volatile disk-backed storage (`jdbc:h2:file:./data/campus_lending_db.mv.db`), guaranteeing survivability across machine reboots and power outages.
2. **Cookie-Backed Hybrid Session Resumption**:
   Authentication state is anchored to a 30-day persistent HTTP cookie (`campus_remember_email`). When a browser tab is reopened or the operating system is restarted, `AuthInterceptor` intercepts the request and reconstructs the session automatically.
3. **Browser Forward-Back Cache (bfcache) Reconciliation**:
   Browsers often store stale DOM snapshots in `bfcache`. An active event listener on `pageshow` intercepts persisted page loads and triggers an automated lightweight synchronization refresh.

---

## 9. Conclusion & Bibliography

The Campus Item Lending & Return System grounds academic resource sharing in formal software engineering paradigms, finite state automata, relational database theory, and cognitive design principles. It establishes full asset traceability, prevents data loss, and delivers an intuitive, role-governed user experience.

### Academic References
1. Ostrom, E. (1990). *Governing the Commons: The Evolution of Institutions for Collective Action*. Cambridge University Press.
2. Codd, E. F. (1970). *A Relational Model of Data for Large Shared Data Banks*. Communications of the ACM, 13(6), 377–387.
3. Ferraiolo, D. F., & Kuhn, D. R. (1992). *Role-Based Access Controls*. 15th National Computer Security Conference, 554–563.
4. Gamma, E., Helm, R., Johnson, R., & Vlissides, J. (1994). *Design Patterns: Elements of Reusable Object-Oriented Software*. Addison-Wesley.
5. Botsman, R., & Rogers, R. (2010). *What's Mine Is Yours: The Rise of Collaborative Consumption*. HarperBusiness.
6. Hopcroft, J. E., Motwani, R., & Ullman, J. D. (2006). *Introduction to Automata Theory, Languages, and Computation* (3rd ed.). Pearson.
7. Nielsen, J. (1994). *Usability Engineering*. Morgan Kaufmann.
