@echo off
title Create Desktop App Shortcut
cd /d "%~dp0"

echo Creating Desktop App Shortcut for Campus Item Lending System...

powershell -Command "$WshShell = New-Object -ComObject WScript.Shell; $scPath = Join-Path ([Environment]::GetFolderPath('Desktop')) 'Campus Item Lending App.lnk'; $Shortcut = $WshShell.CreateShortcut($scPath); $Shortcut.TargetPath = 'wscript.exe'; $Shortcut.Arguments = '\"%~dp0Launch-App-Silent.vbs\"'; $Shortcut.WorkingDirectory = '%~dp0'; $Shortcut.IconLocation = '%~dp0app-icon.ico, 0'; $Shortcut.Description = 'Campus Item Lending & Return System'; $Shortcut.Save(); Write-Host 'Desktop shortcut created successfully!'"

echo.
echo ======================================================================
echo    Shortcut "Campus Item Lending App" placed on your Desktop!
echo ======================================================================
pause
