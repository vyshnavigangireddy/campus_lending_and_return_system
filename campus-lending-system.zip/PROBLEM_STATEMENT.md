# Problem Statement & System Design Specification

## Project Title
**Campus Item Lending & Return System**  
*Enterprise Resource Sharing, Inventory Governance, and Real-Time Equipment Lifecycle Platform*

---

## 1. Executive Summary & Context

Modern university campuses, research institutes, and polytechnic colleges invest millions of dollars in specialized academic and physical assets. These include high-frequency digital oscilloscopes, FPGA development boards, robotics platforms, analytical chemistry glassware, 4K seminar recording equipment, premium engineering courseware, and athletic gear.

While these resources are intended to empower student innovation and interdisciplinary research, institutions face profound operational bottlenecks in making physical items discoverable, equitably accessible, and strictly accountable.

---

## 2. The Core Problem Statement

> **"Higher educational institutions lack a centralized, transparent, and accountable digital mechanism to govern the discovery, lending, authorization, and timely return of departmental physical assets. Existing reliance on paper logbooks, unmonitored verbal loans, and fragmented messaging channels leads to high rates of equipment misplacement, unverified borrower identity, lack of inventory visibility, zero return enforcement, and substantial administrative burden on faculty lenders."**

---

## 3. Detailed Pain Points & Current Workflow Deficiencies

### 3.1. Inventory Invisibility & Resource Silos
- **The Issue**: Equipment owned by the Electrical Engineering department or Physics lab is completely invisible to mechanical, computer science, or robotics students who urgently need it for capstone projects.
- **Consequence**: Duplicate institutional capital expenditures (departments repeatedly buy gear already idling next door) while students face project delays due to lack of gear access.

### 3.2. Fragmented & Informal Lending Chains
- **The Issue**: Physical gear is frequently borrowed via informal agreements, paper sign-out binders, WhatsApp chats, or verbal permission.
- **Consequence**:
  - Sign-out logs get misplaced or smudged.
  - Return due dates are unrecorded and unenforced.
  - Equipment is hoarded past semester deadlines, leaving other students stranded.

### 3.3. Identity Verification & Unauthorized Borrowing
- **The Issue**: Anonymous or unverified borrowers access gear without institutional validation.
- **Consequence**: Items are checked out without verifiable contact details, resulting in permanent equipment loss with no recourse.

### 3.4. Lack of Multi-Role Authorization Hierarchies
- **The Issue**: Systems either treat all users as generic accounts or require complex administrative setups.
- **Consequence**: Faculty members (lenders) cannot approve or reject specific requests on their owned gear, while campus facility heads (approvers) have no high-level oversight over departmental lending volume.

### 3.5. System Fragility & Data Volatility
- **The Issue**: Prototypes often store transactions in volatile memory, causing data loss when servers restart or users navigate away.
- **Consequence**: Loss of audit trails, active loan records, and user session state after browser closures or system restarts.

---

## 4. Proposed Solution & System Objectives

The **Campus Item Lending & Return System** provides an enterprise-grade, responsive full-stack platform built with **Java 21**, **Spring Boot 3**, **MySQL**, **Thymeleaf**, and **modern CSS3** designed to resolve every dimension of the problem:

```
┌──────────────────────────────────────────────────────────────────────────────────┐
│                     CAMPUS ITEM LENDING & RETURN SYSTEM                          │
└────────────────────────────────────────┬─────────────────────────────────────────┘
                                         │
     ┌───────────────────────────────────┼───────────────────────────────────┐
     ▼                                   ▼                                   ▼
┌─────────────────────────┐ ┌─────────────────────────┐ ┌─────────────────────────┐
│   VERIFIED IDENTITY     │ │   REAL-TIME CATALOG     │ │   LIFECYCLE WORKFLOW    │
│ • Valid Campus Email    │ │ • Sub-second search     │ │ • PENDING → Requesting  │
│ • 30-day Session Cache  │ │ • Category Filtering    │ │ • APPROVED → Loan Active│
│ • Role-based Governance │ │ • Live Status Rings     │ │ • RETURNED → Restored   │
└─────────────────────────┘ └─────────────────────────┘ └─────────────────────────┘
```

### Key System Objectives:
1. **Institutional Authentication Gate**: Enforce rigorous campus email format verification so that unauthorized, malformed, or external addresses cannot access the portal.
2. **Transparent Real-Time Catalog**: Sub-second live search and category chips (Electronics, Lab Kits, Books, Sports Gear, Audio/Visual, Robotics) with real-time status pills (`AVAILABLE` with pulsing indicator, `BORROWED`).
3. **Structured Approval Lifecycle**:
   - Students submit requests with exact start dates, due dates, and academic justifications.
   - Item Lenders and Campus Facility Approvers review incoming requests with rapid **Approve** (green checkmark) or **Decline** (red cross) actions.
   - Borrowers can edit or cancel pending requests before approval.
   - Borrowers and Lenders can complete physical check-in through a **Return Item** action that instantly restores the item to `AVAILABLE`.
4. **100% Data Persistence**: Permanent disk-based relational storage ensuring zero data loss across reboots, process termination, and power cycles.

---

## 5. Stakeholder & Persona Analysis

| Stakeholder Role | Primary Responsibilities & Needs | System Capabilities |
| :--- | :--- | :--- |
| 🎓 **Student (Borrower)** | Needs access to lab equipment, calculators, textbooks, and gear for academic projects and extracurricular activities. | • Instant campus email sign-in.<br>• Live inventory search & category filters.<br>• One-click request modal with calendar dates.<br>• Dashboard tracking outgoing requests, with edit, cancel, and return capabilities. |
| 🔬 **Faculty / Lab Owner (Lender)** | Manages high-value department equipment; requires full transparency over who has possession of assets and why. | • List and catalog new department gear.<br>• Review incoming borrow requests for owned gear.<br>• One-click Approve or Decline.<br>• Confirm physical item returns. |
| 🛡️ **Campus Facility Approver** | Department head or facility administrator responsible for campus-wide asset safety and cross-departmental sharing. | • Comprehensive visibility across all campus items.<br>• Universal review and approval rights over all pending requests.<br>• Campus lending metrics and status counters. |
| ⚡ **System Administrator** | Technical custodian of campus IT resources. | • Full inventory and user role governance.<br>• Direct database access and audit logging. |

---

## 6. Functional & Technical Requirements

### 6.1. Functional Requirements (FR)
- **FR-1 [Email Validation]**: System must validate that incoming sign-ins conform to strict RFC email structure and reject invalid entries.
- **FR-2 [Catalog Search]**: System must support instant keyword search across item titles, categories, and descriptions.
- **FR-3 [Request Creation]**: Students can submit lending requests with borrow date, due date, and academic justification.
- **FR-4 [State Transitions]**: Requests must transition through deterministic states: `PENDING` &rarr; `APPROVED` | `REJECTED` &rarr; `RETURNED`.
- **FR-5 [Item Concurrency]**: An item marked `BORROWED` cannot be requested by another user until returned.
- **FR-6 [Owner Restrictions]**: An item owner cannot request to borrow their own equipment.
- **FR-7 [Audit Trail]**: History of completed and declined requests must remain visible on the dashboard.

### 6.2. Non-Functional Requirements (NFR)
- **NFR-1 [Performance]**: Catalog pages and instant searches must respond within &lt; 100 milliseconds.
- **NFR-2 [Persistence]**: All schema tables and transactional records must reside in persistent disk storage.
- **NFR-3 [Usability]**: Design must achieve high aesthetic standards inspired by Linear, Notion, and Airbnb with glassmorphism, responsive grid layouts, and WCAG-compliant status badges.
- **NFR-4 [Portability]**: System must run as a standalone executable JAR package on Windows, Linux, and macOS without requiring external dependencies.

---

## 7. Lifecycle State Machine Diagram

```
       [ Student Submits Request ]
                  │
                  ▼
          ┌───────────────┐
          │    PENDING    │◀─────┐
          └───────┬───────┘      │ (Borrower Edits Request)
                  │              │
       ┌──────────┴──────────┐   └──────────┘
       ▼                     ▼
┌──────────────┐     ┌──────────────┐
│   APPROVED   │     │   REJECTED   │
│(Item: BORROWED)    │(Item: AVAILABLE)
└──────┬───────┘     └──────────────┘
       │
       │ (Borrower / Lender Returns Item)
       ▼
┌──────────────┐
│   RETURNED   │
│(Item: AVAILABLE)
└──────────────┘
```

---

## 8. Measurable Institutional Impact

1. **100% Asset Traceability**: Every piece of lab and athletic gear is linked to a verified campus identity.
2. **Zero Equipment Loss**: Documented due dates, return confirmations, and digital borrower records eliminate unreturned gear.
3. **Optimized Asset Utilization**: Idle equipment in one lab becomes immediately discoverable and usable by other campus departments.
4. **Administrative Efficiency**: Eliminates paper binder overhead and manual spreadsheet logging for lab assistants and department heads.
