# Campus Item Lending & Return System

A modern, full-stack campus equipment and resource lending web application built with **Java 21**, **Spring Boot 3**, **Maven**, **MySQL / JPA**, **Thymeleaf (HTML5)**, and a **100% custom responsive CSS3 design system** inspired by Linear, Notion, and Airbnb.

---

## 📋 Problem Statement

### The Campus Challenge
Higher educational institutions house millions of dollars worth of specialized lab equipment (oscilloscopes, FPGA kits, sensors), textbooks, AV equipment, and athletic gear across various departments. However, universities face persistent operational bottlenecks:

1. **Informal & Misplaced Records**: Equipment lending frequently relies on paper binders, sticky notes, or verbal agreements, resulting in unrecorded loans, overdue equipment, and permanent asset loss.
2. **Departmental Resource Silos**: High-value gear owned by one faculty sits idle while students in adjacent departments face project delays due to lack of gear access.
3. **Unverified Borrower Identity**: Without strict institutional email validation, check-outs occur without verifiable identity or contact records.
4. **Administrative Burden for Faculty**: Lab instructors and item owners lack an automated approval dashboard to quickly approve, reject, or track their loaned inventory.
5. **Data Volatility**: Lightweight campus apps often lose records on system restarts, erasing the history of loans and returns.

### The Solution: Campus Item Lending & Return System
A centralized, responsive, full-stack web platform built to automate and govern the entire lifecycle of physical campus assets:
- **Verified Institutional Authentication Gate**: Enforces valid campus email addresses (`student@college.edu`) with 30-day persistent sessions.
- **Transparent Real-Time Catalog**: Sub-second instant search, category chips, and live status badges (`AVAILABLE` with pulsing ring, `BORROWED`).
- **Role-Based Governance**: Dedicated personas for **Students (Borrowers)**, **Faculty / Lab Owners (Lenders)**, and **Facility Approvers**.
- **End-to-End Governance Cycle**: Request &rarr; Review (`Approve`/`Decline`) &rarr; Active Loan &rarr; Return Confirmation.
- **100% Permanent Disk Persistence**: Zero data loss across machine shutdowns and reboots.

> 📄 *For the full academic/engineering specification, see [PROBLEM_STATEMENT.md](file:///C:/Users/vamsh/.gemini/antigravity/scratch/campus-lending-system/PROBLEM_STATEMENT.md).*

---

## 🎨 1. Visual & UI/UX Design System
- **Color Palette**:
  - Canvas: Crisp `#F8FAFC` light canvas (with dark mode `#0B0F19` support via CSS variables).
  - Primary Accent: Electric Indigo / Vibrant Violet (`#4F46E5` / `#6366F1`) with subtle glow effects on hover (`box-shadow: 0 4px 14px rgba(79, 70, 229, 0.35)`).
- **Status Badges**:
  - `AVAILABLE`: Soft emerald pill with subtle pulsing green ring (`#ECFDF5`, text `#059669`, `@keyframes pulse-ring`).
  - `BORROWED`: Warm slate/amber badge (`#FEF3C7`, text `#D97706`).
  - `PENDING`: Indigo-tinted accent badge (`#EEF2FF`, text `#4F46E5`).
  - `REJECTED`: Soft crimson badge (`#FEF2F2`, text `#DC2626`).
  - `RETURNED`: Soft slate badge (`#F1F5F9`, text `#475569`).
- **Cards & Layout**:
  - 3D soft shadows (`box-shadow: 0 10px 25px -5px rgba(0, 0, 0, 0.05)`).
  - Rounded corners (`border-radius: 14px`).
  - 1px border dividers (`#E2E8F0`).
  - Glassmorphism navigation bar with `backdrop-filter: blur(14px)`.
- **Micro-Interactions**:
  - Smooth scale animations (`transform: translateY(-4px)`) on item cards during hover.
  - Smooth modal popups with blurred backdrop overlays for Request, Edit, Return, and Cancel confirmations.

---

## 🔐 2. Authentication & Roles (Student, Lender, Approver)
- **Strict Email Format Validation**: Access requires a valid campus email format (e.g. `student@college.edu`). Invalid email submissions are rejected with clear user guidance.
- **Frictionless Sign-In**: Instant auto-registration for new emails; instant session login for existing accounts without password friction.
- **Auto-generated Avatars**: Initials extracted and rendered over deterministic color gradients.
- **Supported User Roles**:
  - `STUDENT` (Borrower): Browse catalog, submit requests, edit/cancel pending requests, return borrowed items.
  - `LENDER` (Lab / Faculty Owner): List items, manage inventory, review incoming borrow requests (Approve / Decline).
  - `APPROVER` (Campus Facility Head): Oversee all campus items, review/approve any pending requests across departments.
  - `ADMIN`: Complete system access.
- **1-Click Quick Demo Accounts**:
  - 🎓 **Bob Sharma (Student)**: `bob.student@college.edu`
  - 🔬 **Prof. Alice Vance (Lender)**: `alice.lender@college.edu`
  - 🛡️ **Dr. Robert Miller (Approver)**: `miller.approver@college.edu`

### 🔬 Lender Inventory Creation Access
- **Add Items from Anywhere**: Lenders (and Facility Approvers) have 1-click access to add new equipment directly from:
  1. The **Item Catalog page (`/catalog`)** via the prominent Lender Action Bar.
  2. The **Top Navigation Bar (`[➕ List Item]`)** on every page.
  3. The **Dashboard (`/dashboard?tab=items`)** under the *My Listed Items* tab.
- **1-Click Photo Presets & Live Image Preview**: Modal includes quick preset photography buttons (⚡ Oscilloscope, 🔬 Microscope, 🤖 4K Drone, 🖨️ 3D Printer, 📷 4K Camera, 📚 Course Book) with instant visual preview.
- **Immediate Catalog Sync**: Newly listed items instantly appear in the live catalog, ready for student reservation.

---

## ⏰ 3. Student 1-Day Return Intimation Email System

A fully automated reminder notification pipeline that protects institutional equipment from becoming overdue:

- **Automated 24-Hour Scheduling**: Spring Boot `@Scheduled` background worker runs daily at 08:00 AM (and sweeps hourly) to detect all active student loans whose return deadline is **tomorrow** (`due_date == LocalDate.now().plusDays(1)`).
- **High-Design HTML Intimation Email**: Dispatched directly to the student's campus email address (`borrower.getEmail()`) featuring:
  - Official University Resource Hub branding & urgent 1-Day return badge.
  - Complete equipment specification, category, and scheduled due date.
  - Assigned lender faculty name, lab location, and direct contact email.
  - Departmental return checklist (cables, probes, safety packing).
- **On-Demand Intimation Trigger & Testing**:
  - **Lender One-Click Intimate Action**: In the incoming requests dashboard, lenders can click **"📧 Intimate Student"** next to any active loan to dispatch an immediate 1-day notice.
  - **System-Wide Scan Button**: Click **"⚡ Run 1-Day Intimation Scan Now"** on the dashboard to immediately evaluate all campus loans.
- **Interactive In-App Notification Log**: Students and Lenders can open the **"⏰ 1-Day Intimations"** tab on their dashboard to view all sent notices and click **"👁️ View Mail"** to inspect the rendered HTML email in an interactive modal.
- **Production SMTP + Offline Simulation**:
  - Configurable for live university SMTP servers (e.g. Gmail, Outlook, Amazon SES) via `spring.mail.*` properties.
  - Automatically falls back to clean in-memory & database logging (`RECORDED_IN_APP` / `ACTIVE_SIMULATED`) for safe local testing without external internet dependencies.

---

## 🔄 4. Complete Lending Request CRUD Lifecycle
1. **Browse & Search**: Real-time live keyword search (instant client-side filtering) + category chips (Electronics, Lab Kits, Books, Sports Gear, etc.).
2. **Borrow Action**: Clicking *"Request to Borrow"* opens a sleek modal pre-filled with the item name, requiring start date, return date, and academic purpose. Creates a `PENDING` request.
3. **Edit Pending Request**: Borrower can click *"Edit"* on their dashboard to modify dates and purpose while in `PENDING` state.
4. **Cancel / Delete Request**: Borrower can click *"Cancel"* with a confirmation popup to delete the request.
5. **Approval Cycle**:
   - Item Owner or Approver sees incoming requests with quick *"Approve"* (green checkmark) and *"Decline"* (red cross) actions.
   - Upon approval, the request moves to `APPROVED` and the item is marked as `BORROWED`.
6. **1-Day Intimation Reminder**:
   - Exactly 1 day prior to the due date, the student automatically receives the return intimation email!
7. **Return Item**:
   - Borrower or Lender sees *"Return Item"*.
   - Confirming return updates request to `RETURNED` and restores the item status to `AVAILABLE` in the catalog!

---

## 🗄️ 4. Database Schema (MySQL)

```sql
CREATE TABLE users (
    id BIGINT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(100) NOT NULL,
    email VARCHAR(150) UNIQUE NOT NULL,
    role VARCHAR(30) DEFAULT 'STUDENT',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE items (
    id BIGINT AUTO_INCREMENT PRIMARY KEY,
    owner_id BIGINT NOT NULL,
    title VARCHAR(120) NOT NULL,
    category VARCHAR(50) NOT NULL,
    description TEXT,
    status VARCHAR(30) DEFAULT 'AVAILABLE',
    image_url VARCHAR(255),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (owner_id) REFERENCES users(id) ON DELETE CASCADE
);

CREATE TABLE borrow_requests (
    id BIGINT AUTO_INCREMENT PRIMARY KEY,
    item_id BIGINT NOT NULL,
    borrower_id BIGINT NOT NULL,
    status VARCHAR(30) DEFAULT 'PENDING',
    borrow_date DATE NOT NULL,
    due_date DATE NOT NULL,
    purpose VARCHAR(255),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (item_id) REFERENCES items(id) ON DELETE CASCADE,
    FOREIGN KEY (borrower_id) REFERENCES users(id) ON DELETE CASCADE
);
```

---

## 🚀 5. How to Run

## 🚀 5. Permanent Persistence & How to Run Like an App

### 💾 100% Permanent Disk-Based Persistence
- **Database Storage**: Saved permanently on disk at `./data/campus_lending_db.mv.db`. Every item added, request created, approval granted, and user registration survives across all computer shutdowns, reboots, and restarts!
- **Session Auto-Restoration**: Users stay logged in across browser closures, computer restarts, and browser "Back" navigation through 30-day persistent cookies.
- **Browser Back Button Fix**: Navigation back and forward never freezes or breaks; live page state is restored with no stale cache resubmissions.

### 🖥️ Running as a Standalone Desktop Application ("Like an App")
You can run and access the application in multiple native desktop styles:

1. **Standalone App Window Mode (Recommended)**:
   - Double-click **`Launch-Campus-App.bat`**.
   - Launches the backend server in the background and opens the portal in a **dedicated, frameless native app window** (via Edge/Chrome `--app` mode) with a clean titlebar and no browser clutter (URL bar or tabs).

2. **Silent Background App Launcher (Zero Console Window)**:
   - Double-click **`Launch-App-Silent.vbs`**.
   - Starts the application and launches the app window completely silently without showing any black CMD prompt window.

3. **Install as a Windows PWA (Start Menu & Taskbar)**:
   - Open the app in any modern browser and click the **"📲 Install App"** button located in the top navigation bar.
   - Or click the browser address bar install icon.
   - The app installs as a native Windows application with its own high-res icon, launchable directly from your Windows Start Menu and taskbar.

4. **1-Click Browser Launcher**:
   - Double-click **`start-app.bat`** (launches server and automatically opens `http://localhost:8080/catalog` in your default browser).

5. **To Stop Anytime**:
   - Double-click **`stop-app.bat`** (cleanly frees port 8080 and halts the background service).

### Manual Run Options
```bash
# Option A: Run pre-built standalone production JAR (fastest, 2-3 sec startup)
java -jar target/campus-lending-system-1.0.0.jar

# Option B: Run via Maven wrapper
./mvnw.cmd spring-boot:run

# Option C: Run with local MySQL server
./mvnw.cmd spring-boot:run -Dspring-boot.run.profiles=mysql
```

---

## 🧪 6. Running Tests
```bash
./mvnw.cmd test
```
All integration and unit tests verify email validation, authentication, role routing, and full request lifecycles.
